import { execSync, spawn } from 'child_process';
import express from 'express';
import fs from 'fs';
import http from 'http';
import https from 'https';
import path from 'path';
import { createServer as createViteServer } from 'vite';

const PUBLIC_APP_URL = (
  process.env.APP_URL ||
  process.env.RENDER_EXTERNAL_URL ||
  'https://ais-dev-3h2c3yfgusnpkwaet556wl-520499311404.asia-east1.run.app'
).replace(/\/+$/, '');

const PORT = Number(process.env.PORT) || 3000;
const DATA_DIR = path.resolve(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'boiler_store_v3.json');

const SUPABASE_URL = process.env.SUPABASE_URL || 'https://yikekymtticqabnlsmdo.supabase.co';
const SUPABASE_KEY = process.env.SUPABASE_KEY || 'sb_publishable_UY0NZTIxVQ7kF69iReLrLA_Cm6DcbsA';

const SB_HEADERS = {
  apikey: SUPABASE_KEY,
  Authorization: `Bearer ${SUPABASE_KEY}`,
  'Content-Type': 'application/json',
};

export interface BoilerOption {
  id: string;
  name: string;
  active: boolean;
  sort_order: number;
}

export interface ChemicalConfig {
  id: string;
  code: string;
  name: string;
  divisor: number;
  unit: string;
  active: boolean;
  sort_order: number;
  description?: string;
}

export interface CalculationDetailItem {
  name: string;
  prev?: number;
  curr: number;
  divisor?: number;
  report: string;
  note?: string;
}

export interface CalculationHistoryRecord {
  id: string;
  client_record_id: string;
  boiler_id: string | null;
  boiler_name: string;
  recorder_name: string;
  shift?: string;
  note?: string;
  calculated_at: string;
  details: CalculationDetailItem[];
  synced_supabase?: boolean;
}

export interface AppPermissions {
  allow_calculate: boolean;
  allow_save: boolean;
  allow_history_view: boolean;
  allow_history_delete: boolean;
  allow_share: boolean;
  allow_chemical_info: boolean;
}

export interface AppSettings {
  site_name: string;
  app_version: string;
  developer_name: string;
  copyright_name: string;
  department_name: string;
  announcement: string;
  preview_image_url?: string;
  admin_pin: string;
  pin_initialized: boolean;
  gas_webapp_url: string;
  db_mode: 'HYBRID_SUPABASE' | 'SUPABASE_ONLY' | 'LOCAL_GAS';
  permissions: AppPermissions;
  updated_at: string;
}

interface LocalDatabase {
  settings: AppSettings;
  boilers: BoilerOption[];
  chemicals: ChemicalConfig[];
  history: CalculationHistoryRecord[];
  deleted_history_ids?: string[];
  audit_logs: Array<{ id: string; action: string; details: string; created_at: string }>;
}

const nowIso = () => new Date().toISOString();

const DEFAULT_DB: LocalDatabase = {
  settings: {
    site_name: 'Boiler Chemical',
    app_version: '3.0.0',
    developer_name: 'Weevanh Khambounheuang',
    copyright_name: 'Weevanh Khambounheuang',
    department_name: 'แผนกบอยเลอร์ (Steam Boiler Department)',
    announcement: '',
    preview_image_url: '',
    admin_pin: '',
    pin_initialized: true,
    gas_webapp_url: '',
    db_mode: 'HYBRID_SUPABASE',
    permissions: {
      allow_calculate: true,
      allow_save: true,
      allow_history_view: true,
      allow_history_delete: true,
      allow_share: true,
      allow_chemical_info: true,
    },
    updated_at: nowIso(),
  },
  boilers: [
    { id: 'd76e193b-903b-4b22-a0af-654b948f4218', name: 'Boiler #1-2', active: true, sort_order: 1 },
    { id: '437f1304-d144-452a-9a0c-d2b71b1e8ec3', name: 'Boiler #3', active: true, sort_order: 2 },
  ],
  chemicals: [
    {
      id: 'ea1a770f-3c27-4a6c-8f00-367f0c43eeda',
      code: 'MCC-N',
      name: 'MCC-N',
      divisor: 4,
      unit: 'L',
      active: true,
      sort_order: 1,
      description: 'สารป้องกันตะกรัน ป้องกันการกัดกร่อน และควบคุมฟองในหม้อต้ม (หาร 4)',
    },
    {
      id: 'e0c5af2a-8d06-44ef-82e0-8d2267463337',
      code: 'POLY-SRB',
      name: 'PolyTreat-SRB',
      divisor: 4,
      unit: 'L',
      active: true,
      sort_order: 2,
      description: 'สารทำลายและควบคุมแบคทีเรีย SRB ลดการกัดกร่อนจากจุลชีพและกำจัดกลิ่น (หาร 4)',
    },
    {
      id: 'b71673f0-d26d-44e6-bcab-660d1e8cc25a',
      code: 'TCE-2138',
      name: 'TCE-2138',
      divisor: 8,
      unit: 'L',
      active: true,
      sort_order: 3,
      description: 'สารป้องกันการเกิดตะกรันและป้องกันสนิมการกัดกร่อนในหม้อต้มไอน้ำ (หาร 8)',
    },
  ],
  history: [],
  deleted_history_ids: [],
  audit_logs: [],
};

function normalizeBoilerDisplayName(name: string): string {
  const trimmed = String(name || '').trim();
  if (/^boiler\s*#\s*1\s*-\s*2$/i.test(trimmed)) return 'Boiler #1-2';
  if (/^boiler\s*#\s*3$/i.test(trimmed)) return 'Boiler #3';
  return trimmed;
}

function deduplicateHistory(
  records: CalculationHistoryRecord[],
  deletedIds: Set<string>
): CalculationHistoryRecord[] {
  const seenIds = new Set<string>();
  const seenClientIds = new Set<string>();
  const seenSignatures = new Set<string>();
  const result: CalculationHistoryRecord[] = [];

  const sorted = [...records].sort(
    (a, b) => new Date(b.calculated_at).getTime() - new Date(a.calculated_at).getTime()
  );

  for (const rec of sorted) {
    if (!rec || !rec.id) continue;
    if (String(rec.id).startsWith('seed-calc-')) continue;
    if (deletedIds.has(rec.id) || (rec.client_record_id && deletedIds.has(rec.client_record_id))) {
      continue;
    }

    const normBoiler = normalizeBoilerDisplayName(rec.boiler_name);
    const sig = `${normBoiler.toLowerCase()}|${rec.calculated_at}|${JSON.stringify(rec.details || [])}`;

    if (seenIds.has(rec.id)) continue;
    if (rec.client_record_id && seenClientIds.has(rec.client_record_id)) continue;
    if (seenSignatures.has(sig)) continue;

    seenIds.add(rec.id);
    if (rec.client_record_id) seenClientIds.add(rec.client_record_id);
    seenSignatures.add(sig);

    result.push({
      ...rec,
      boiler_name: normBoiler,
    });
  }

  return result;
}

function loadDb(): LocalDatabase {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    if (!fs.existsSync(DB_FILE)) {
      fs.writeFileSync(DB_FILE, JSON.stringify(DEFAULT_DB, null, 2), 'utf-8');
      return structuredClone(DEFAULT_DB);
    }
    const raw = fs.readFileSync(DB_FILE, 'utf-8');
    const parsed = JSON.parse(raw) as Partial<LocalDatabase>;
    const deletedIdsList = Array.isArray(parsed.deleted_history_ids)
      ? parsed.deleted_history_ids.map(String)
      : [];
    const deletedSet = new Set(deletedIdsList);

    const rawBoilers =
      Array.isArray(parsed.boilers) && parsed.boilers.length > 0
        ? parsed.boilers
        : DEFAULT_DB.boilers;

    // Deduplicate boilers by normalized name
    const seenBoilerNames = new Set<string>();
    const cleanBoilers: BoilerOption[] = [];
    for (const b of rawBoilers) {
      const normName = normalizeBoilerDisplayName(b.name);
      const key = normName.toLowerCase();
      if (seenBoilerNames.has(key)) continue;
      seenBoilerNames.add(key);
      cleanBoilers.push({
        ...b,
        name: normName,
      });
    }

    const cleanHistory = deduplicateHistory(
      Array.isArray(parsed.history) ? parsed.history : [],
      deletedSet
    );

    return {
      settings: {
        ...DEFAULT_DB.settings,
        ...(parsed.settings || {}),
        admin_pin: parsed.settings?.admin_pin === '1234' ? '' : (parsed.settings?.admin_pin || ''),
        permissions: {
          ...DEFAULT_DB.settings.permissions,
          ...(parsed.settings?.permissions || {}),
        },
      },
      boilers: cleanBoilers,
      chemicals:
        Array.isArray(parsed.chemicals) && parsed.chemicals.length > 0
          ? parsed.chemicals
          : DEFAULT_DB.chemicals,
      history: cleanHistory,
      deleted_history_ids: deletedIdsList,
      audit_logs: Array.isArray(parsed.audit_logs) ? parsed.audit_logs : DEFAULT_DB.audit_logs,
    };
  } catch (err) {
    console.error('Error loading local boiler store:', err);
    return structuredClone(DEFAULT_DB);
  }
}

function saveDb(db: LocalDatabase): void {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2), 'utf-8');
  } catch (err) {
    console.error('Error saving local boiler store:', err);
  }
}

function addAuditLog(db: LocalDatabase, action: string, details: string) {
  db.audit_logs = [
    {
      id: `audit_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      action,
      details,
      created_at: nowIso(),
    },
    ...(db.audit_logs || []),
  ].slice(0, 100);
}

async function callSupabaseRpc(name: string, payload: Record<string, unknown> = {}) {
  try {
    const res = await fetch(`${SUPABASE_URL}/rest/v1/rpc/${name}`, {
      method: 'POST',
      headers: SB_HEADERS,
      body: JSON.stringify(payload),
    });
    const data = await res.json().catch(() => null);
    return { status: res.status, ok: res.ok, data };
  } catch (err) {
    return { status: 500, ok: false, data: null, error: String(err) };
  }
}

async function mirrorToGoogleSheet(url: string, action: string, payload: unknown) {
  if (!url || !url.startsWith('https://script.google.com/')) return false;
  try {
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action, payload, timestamp: nowIso() }),
    });
    return res.ok;
  } catch (err) {
    console.warn('Google Apps Script mirror warning:', err);
    return false;
  }
}

async function ensureSupabaseSessionToken(db: LocalDatabase, token?: string): Promise<string> {
  if (token && !token.startsWith('admin_') && !token.startsWith('sb_local_')) {
    return token;
  }
  const pinToTry = db.settings.admin_pin || '1221';
  const sbLogin = await callSupabaseRpc('admin_login', { p_pin: pinToTry });
  const loginData = sbLogin.data as { ok?: boolean; session_token?: string } | null;
  if (loginData?.ok && loginData.session_token) {
    return loginData.session_token;
  }
  return token || '';
}

async function syncFromSupabase(db: LocalDatabase): Promise<{ online: boolean; pinInitialized: boolean }> {
  try {
    const [boilerRes, chemRes, histRes, cfgRes, adminStRes, sysSetRes] = await Promise.allSettled([
      fetch(`${SUPABASE_URL}/rest/v1/boilers?select=*&order=sort_order.asc`, { headers: SB_HEADERS }),
      fetch(`${SUPABASE_URL}/rest/v1/chemicals?select=*&order=sort_order.asc`, { headers: SB_HEADERS }),
      fetch(`${SUPABASE_URL}/rest/v1/calculation_history?select=*&order=calculated_at.desc&limit=5000`, {
        headers: SB_HEADERS,
      }),
      callSupabaseRpc('public_get_app_config'),
      callSupabaseRpc('admin_status'),
      fetch(`${SUPABASE_URL}/rest/v1/system_settings?select=setting_key,setting_value`, {
        headers: SB_HEADERS,
      }),
    ]);

    let online = false;
    let pinInitialized = Boolean(db.settings.admin_pin);
    const deletedSet = new Set(db.deleted_history_ids || []);

    if (adminStRes.status === 'fulfilled' && adminStRes.value.ok && adminStRes.value.data) {
      online = true;
      const st = adminStRes.value.data as { initialized?: boolean };
      if (st.initialized !== undefined) {
        pinInitialized = Boolean(st.initialized) || Boolean(db.settings.admin_pin);
      }
    }

    if (boilerRes.status === 'fulfilled' && boilerRes.value.ok) {
      online = true;
      const remoteBoilers = (await boilerRes.value.json()) as Array<Record<string, unknown>>;
      if (Array.isArray(remoteBoilers) && remoteBoilers.length > 0) {
        const activeRemote = remoteBoilers.filter((b) => b && b.name && b.active !== false);
        if (activeRemote.length > 0) {
          const syncedBoilers: BoilerOption[] = [];
          const seenNames = new Set<string>();
          for (const rb of activeRemote) {
            const rName = normalizeBoilerDisplayName(String(rb.name || ''));
            if (!rName) continue;
            const key = rName.toLowerCase();
            if (seenNames.has(key)) continue;
            seenNames.add(key);
            syncedBoilers.push({
              id: String(rb.id),
              name: rName,
              active: true,
              sort_order: Number(rb.sort_order ?? syncedBoilers.length + 1),
            });
          }
          if (syncedBoilers.length > 0) {
            db.boilers = syncedBoilers;
          }
        }
      }
    }

    if (chemRes.status === 'fulfilled' && chemRes.value.ok) {
      online = true;
      const remoteChems = (await chemRes.value.json()) as Array<Record<string, unknown>>;
      if (Array.isArray(remoteChems) && remoteChems.length > 0) {
        const activeRemoteChems = remoteChems.filter((rc) => rc && rc.name && rc.active !== false);
        if (activeRemoteChems.length > 0) {
          const syncedChems: ChemicalConfig[] = [];
          const seenNames = new Set<string>();
          for (const rc of activeRemoteChems) {
            const rawName = String(rc.name || '').trim();
            const normalizedName = rawName.toLowerCase() === 'polytreat-srp' ? 'PolyTreat-SRB' : rawName;
            if (!normalizedName) continue;
            const key = normalizedName.toLowerCase();
            if (seenNames.has(key)) continue;
            seenNames.add(key);
            syncedChems.push({
              id: String(rc.id),
              code: String(rc.code || normalizedName),
              name: normalizedName,
              divisor: Number(rc.divisor) || 4,
              unit: String(rc.unit || 'L'),
              active: true,
              sort_order: Number(rc.sort_order ?? syncedChems.length + 1),
            });
          }
          if (syncedChems.length > 0) {
            db.chemicals = syncedChems;
          }
        }
      }
    }

    if (histRes.status === 'fulfilled' && histRes.value.ok) {
      online = true;
      const remoteHist = (await histRes.value.json()) as Array<Record<string, unknown>>;
      if (Array.isArray(remoteHist)) {
        const remoteIdSet = new Set(remoteHist.map((rh) => String(rh.id || '')).filter(Boolean));
        const localUnsynced = db.history.filter(
          (h) => !h.synced_supabase && !remoteIdSet.has(h.id) && !deletedSet.has(h.id)
        );
        const merged: CalculationHistoryRecord[] = [...localUnsynced];
        for (const rh of remoteHist) {
          const id = String(rh.id || '');
          const clientId = String(rh.client_record_id || '');
          if (!id || deletedSet.has(id) || (clientId && deletedSet.has(clientId))) continue;
          const rawDetails = Array.isArray(rh.details) ? (rh.details as CalculationDetailItem[]) : [];
          const extractedNote =
            typeof rh.note === 'string' && rh.note.trim()
              ? rh.note.trim()
              : rawDetails.find((d) => typeof d?.note === 'string' && d.note.trim())?.note?.trim() || '';
          merged.push({
            id,
            client_record_id: clientId || id,
            boiler_id: rh.boiler_id ? String(rh.boiler_id) : null,
            boiler_name: normalizeBoilerDisplayName(String(rh.boiler_name || 'Boiler')),
            recorder_name: String(rh.recorder_name || 'แผนกบอยเลอร์'),
            ...(extractedNote ? { note: extractedNote } : {}),
            calculated_at: String(rh.calculated_at || rh.created_at || nowIso()),
            details: rawDetails,
            synced_supabase: true,
          });
        }
        db.history = deduplicateHistory(merged, deletedSet);
      }

      // Push any local unsynced records to Supabase so every device sees 100% of records
      for (const localRec of db.history) {
        if (!localRec.synced_supabase) {
          try {
            const uuidBoilerId =
              localRec.boiler_id &&
              /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(localRec.boiler_id)
                ? localRec.boiler_id
                : null;
            const recNote = String(localRec.note || '').trim();
            const pushRes = await fetch(`${SUPABASE_URL}/rest/v1/calculation_history`, {
              method: 'POST',
              headers: {
                ...SB_HEADERS,
                Prefer: 'resolution=ignore-duplicates,return=representation',
              },
              body: JSON.stringify({
                client_record_id: localRec.client_record_id,
                boiler_id: uuidBoilerId,
                boiler_name: localRec.boiler_name,
                recorder_name: localRec.recorder_name || 'แผนกบอยเลอร์',
                calculated_at: localRec.calculated_at,
                details: (localRec.details || []).map((d) => ({
                  name: d.name,
                  report: d.report,
                  curr: d.curr,
                  ...(d.note || recNote ? { note: String(d.note || recNote).trim() } : {}),
                })),
              }),
            });
            if (pushRes.ok) {
              localRec.synced_supabase = true;
            }
          } catch (_e) {
            // Will retry on next sync
          }
        }
      }
    }

    if (cfgRes.status === 'fulfilled' && cfgRes.value.ok && cfgRes.value.data) {
      online = true;
      const cfg = cfgRes.value.data as Record<string, unknown>;
      if (cfg.permissions && typeof cfg.permissions === 'object') {
        db.settings.permissions = {
          ...db.settings.permissions,
          ...(cfg.permissions as Partial<AppPermissions>),
        };
      }
      if (typeof cfg.site_name === 'string' && cfg.site_name.trim()) {
        db.settings.site_name = cfg.site_name.trim();
      }
      if (typeof cfg.app_version === 'string' && cfg.app_version.trim()) {
        db.settings.app_version = cfg.app_version.trim();
      }
      if (typeof cfg.preview_image_url === 'string') {
        db.settings.preview_image_url = cfg.preview_image_url.trim();
      }
    }

    if (sysSetRes.status === 'fulfilled' && sysSetRes.value.ok) {
      const sysRows = (await sysSetRes.value.json()) as Array<{
        setting_key?: string;
        setting_value?: unknown;
      }>;
      if (Array.isArray(sysRows)) {
        for (const row of sysRows) {
          if (row.setting_key === 'preview_image_url') {
            const valObj = row.setting_value as { value?: string } | string | null;
            const extracted =
              typeof valObj === 'string'
                ? valObj
                : valObj && typeof valObj === 'object' && typeof valObj.value === 'string'
                ? valObj.value
                : '';
            db.settings.preview_image_url = extracted.trim();
          }
        }
      }
    }

    db.settings.pin_initialized = pinInitialized;
    saveDb(db);
    return { online, pinInitialized };
  } catch (err) {
    console.warn('Supabase sync check error:', err);
    return { online: false, pinInitialized: Boolean(db.settings.admin_pin) || true };
  }
}

function ensurePublicAccessEnabled(): void {
  try {
    let changed = false;

    const luaAuthPath = '/etc/nginx/user_auth_verification.lua';
    if (fs.existsSync(luaAuthPath)) {
      const luaRaw = fs.readFileSync(luaAuthPath, 'utf-8');
      if (!luaRaw.startsWith('if true then return end')) {
        fs.writeFileSync(luaAuthPath, `if true then return end\n${luaRaw}`, 'utf-8');
        changed = true;
      }
    }

    const cleanAuthInclude = `location = /__keepalive_stream {
    proxy_pass http://127.0.0.1:3999/stream;
    proxy_http_version 1.1;
    proxy_set_header Connection "";
    proxy_buffering off;
    proxy_cache off;
    proxy_read_timeout 3600s;
    proxy_send_timeout 3600s;
}
location = /__cookie_check.html {
    add_header Cache-Control "no-cache, no-store, must-revalidate";
    return 302 https://$host/;
}
location /forbidden.html {
    add_header Cache-Control "no-cache, no-store, must-revalidate";
    return 302 https://$host/;
}
`;

    const authIncludePath = '/etc/nginx/nginx_auth.conf.include';
    if (fs.existsSync(authIncludePath)) {
      const incRaw = fs.readFileSync(authIncludePath, 'utf-8');
      if (incRaw !== cleanAuthInclude) {
        fs.writeFileSync(authIncludePath, cleanAuthInclude, 'utf-8');
        changed = true;
      }
    }

    const nginxFiles = ['/etc/nginx/nginx.conf', '/etc/nginx/nginx.conf.template'];
    for (const filePath of nginxFiles) {
      if (fs.existsSync(filePath)) {
        let updated = fs.readFileSync(filePath, 'utf-8');
        let fileChanged = false;
        if (updated.includes('env DISABLE_AUTH_BRIDGE;') && !updated.includes('env DISABLE_AUTH_BRIDGE=true;')) {
          updated = updated.replace('env DISABLE_AUTH_BRIDGE;', 'env DISABLE_AUTH_BRIDGE=true;');
          fileChanged = true;
        }
        if (!updated.includes('worker_shutdown_timeout')) {
          updated = updated.replace('worker_processes auto;', 'worker_processes auto;\nworker_shutdown_timeout 2s;');
          fileChanged = true;
        }
        if (updated.includes('proxy_read_timeout 300s;')) {
          updated = updated.replace(/proxy_read_timeout 300s;/g, 'proxy_read_timeout 3600s;');
          fileChanged = true;
        }
        if (updated.includes('proxy_send_timeout 300s;')) {
          updated = updated.replace(/proxy_send_timeout 300s;/g, 'proxy_send_timeout 3600s;');
          fileChanged = true;
        }
        if (updated.includes('\n            access_by_lua_file /etc/nginx/user_auth_verification.lua;')) {
          updated = updated.replace(
            '\n            access_by_lua_file /etc/nginx/user_auth_verification.lua;',
            '\n            # access_by_lua_file disabled for public access'
          );
          fileChanged = true;
        }
        if (updated.includes('add_header Content-Security-Policy "frame-ancestors')) {
          updated = updated.replace(
            /add_header Content-Security-Policy "frame-ancestors[^;]*;/g,
            '# frame-ancestors unrestricted for public access'
          );
          fileChanged = true;
        }
        if (fileChanged) {
          fs.writeFileSync(filePath, updated, 'utf-8');
          changed = true;
        }
      }
    }

    const autoRedirectHtml = `<!doctype html>
<html lang="th">
<head>
  <meta charset="utf-8" />
  <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
  <meta http-equiv="Pragma" content="no-cache" />
  <meta http-equiv="Expires" content="0" />
  <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no" />
  <title>Boiler Chemical</title>
  <script>
    (function() {
      try {
        var params = new URLSearchParams(window.location.search);
        var ret = params.get('return_url');
        if (ret && /^https?:\\/\\//i.test(ret)) {
          window.location.replace(ret);
          return;
        }
      } catch (e) {}
      window.location.replace('/');
    })();
  </script>
</head>
<body style="margin:0;background:#f8f9fb;font-family:sans-serif;display:flex;align-items:center;justify-content:center;height:100vh;color:#0369a1;font-weight:bold;font-size:14px;">
  กำลังเปิดแอป Boiler Chemical...
</body>
</html>`;

    const cookieCheckPath = '/var/www/assets/cookie_check.html';
    if (fs.existsSync(cookieCheckPath)) {
      const currentCookieHtml = fs.readFileSync(cookieCheckPath, 'utf-8');
      if (currentCookieHtml !== autoRedirectHtml) {
        fs.writeFileSync(cookieCheckPath, autoRedirectHtml, 'utf-8');
        changed = true;
      }
    }

    const forbiddenPath = '/var/www/assets/forbidden.html';
    try {
      if (!fs.existsSync(forbiddenPath) || fs.readFileSync(forbiddenPath, 'utf-8') !== autoRedirectHtml) {
        fs.writeFileSync(forbiddenPath, autoRedirectHtml, 'utf-8');
        changed = true;
      }
    } catch (_e) {
      // Ignore if read-only
    }

    const warmupPath = '/var/www/assets/warmup.html';
    const customWarmupHtml = `<!doctype html>
<html lang="th">
<head>
  <meta charset="utf-8" />
  <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
  <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no" />
  <title>Boiler Chemical</title>
  <script>
    setInterval(function() {
      fetch('/api/keepalive?t=' + Date.now(), { cache: 'no-store' })
        .then(function(r) { if (r.ok) window.location.replace('/'); })
        .catch(function() {});
    }, 1000);
    setTimeout(function() { window.location.reload(); }, 3000);
  </script>
</head>
<body style="margin:0;background:#f8f9fb;font-family:sans-serif;display:flex;align-items:center;justify-content:center;height:100vh;color:#0369a1;font-weight:bold;font-size:14px;">
  กำลังเชื่อมต่อระบบ Boiler Chemical อัตโนมัติ...
</body>
</html>`;
    if (fs.existsSync(warmupPath)) {
      const currentWarmup = fs.readFileSync(warmupPath, 'utf-8');
      if (currentWarmup !== customWarmupHtml) {
        fs.writeFileSync(warmupPath, customWarmupHtml, 'utf-8');
        changed = true;
      }
    }

    if (changed) {
      execSync('nginx -s reload', { stdio: 'ignore' });
      try {
        execSync('pkill -9 -f "worker process is shutting down" || true', { stdio: 'ignore' });
      } catch (_e) {
        // Ignore
      }
    }
  } catch (_err) {
    // Ignore when running outside the container environment
  }
}

function ensureDaemonProcessRunning(): void {
  try {
    for (const oldPidFile of ['/tmp/boiler-always-on-daemon.pid', '/tmp/boiler-always-on-daemon-v2.pid']) {
      if (fs.existsSync(oldPidFile)) {
        try {
          const oldPid = Number(fs.readFileSync(oldPidFile, 'utf-8').trim());
          if (oldPid > 0) process.kill(oldPid, 'SIGTERM');
        } catch (_e) {
          // Ignore
        }
        try {
          fs.unlinkSync(oldPidFile);
        } catch (_e) {
          // Ignore
        }
      }
    }

    const daemonScriptPath = '/tmp/boiler-always-on-daemon-v3.mjs';
    const daemonPidPath = '/tmp/boiler-always-on-daemon-v3.pid';
    if (fs.existsSync(daemonPidPath)) {
      const existingPid = Number(fs.readFileSync(daemonPidPath, 'utf-8').trim());
      if (existingPid > 0) {
        try {
          process.kill(existingPid, 0);
          return;
        } catch (_e) {
          // Process not running, respawn below
        }
      }
    }

    const daemonCode = `
import fs from 'fs';
import http from 'http';
import https from 'https';
import { execSync, spawn } from 'child_process';

const PUBLIC_URL = ${JSON.stringify(PUBLIC_APP_URL)};
const PID_FILE = '/tmp/boiler-always-on-daemon-v3.pid';
fs.writeFileSync(PID_FILE, String(process.pid), 'utf-8');

const server = http.createServer((req, res) => {
  if (req.url && req.url.startsWith('/stream')) {
    res.writeHead(200, {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache, no-store, must-revalidate',
      'Connection': 'keep-alive',
      'X-Accel-Buffering': 'no'
    });
    res.write('data: connected_' + Date.now() + '\\n\\n');
    const hb = setInterval(() => {
      try {
        res.write('data: ' + Date.now() + '\\n\\n');
      } catch {
        clearInterval(hb);
      }
    }, 2500);
    // Keep server-side stream alive for up to 50 minutes (3,000,000 ms) so it NEVER closes before client replacement
    const maxTimer = setTimeout(() => {
      clearInterval(hb);
      try { res.end(); } catch {}
    }, 3000000);
    req.on('close', () => {
      clearInterval(hb);
      clearTimeout(maxTimer);
    });
    return;
  }
  res.writeHead(200, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify({ ok: true, ts: Date.now() }));
});

server.on('error', () => {});

server.listen(3999, '127.0.0.1', () => {
  for (let i = 1; i <= 5; i++) {
    setTimeout(() => maintainNonPooledSlot('/__keepalive_stream', i), i * 800);
  }
  for (let i = 6; i <= 8; i++) {
    setTimeout(() => maintainNonPooledSlot('/api/keepalive-stream', i), i * 1000);
  }
});

function maintainNonPooledSlot(pathUrl, slotId) {
  let activeReq = null;
  let rotateTimer = null;
  let retryTimer = null;
  const rotateIntervalMs = 140000 + slotId * 13000;

  function scheduleRetry(delayMs) {
    if (retryTimer) clearTimeout(retryTimer);
    retryTimer = setTimeout(() => {
      retryTimer = null;
      openCandidate();
    }, delayMs);
  }

  function openCandidate() {
    if (rotateTimer) {
      clearTimeout(rotateTimer);
      rotateTimer = null;
    }

    let promoted = false;
    let settled = false;
    const targetUrl = PUBLIC_URL + pathUrl + '?slot=' + slotId + '&r=' + Date.now() + '_' + Math.random().toString(36).slice(2, 7);

    const req = https.get(
      targetUrl,
      {
        agent: false,
        headers: {
          'Cache-Control': 'no-cache, no-store, must-revalidate',
          'Pragma': 'no-cache',
          'Accept': 'text/event-stream',
          'Connection': 'keep-alive',
          'User-Agent': 'BoilerChemicalAlwaysOn/3.0 (slot-' + slotId + ')'
        },
        timeout: 15000
      },
      (res) => {
        if (res.statusCode !== 200) {
          res.resume();
          try { req.destroy(); } catch {}
          if (!settled) {
            settled = true;
            scheduleRetry(1500);
          }
          return;
        }

        res.on('data', () => {
          if (!promoted) {
            promoted = true;
            clearTimeout(handshakeGuard);
            const oldReq = activeReq;
            activeReq = req;

            // Keep BOTH oldReq and new req open simultaneously for 6 full seconds
            if (oldReq && oldReq !== req) {
              setTimeout(() => {
                try { oldReq.destroy(); } catch {}
              }, 6000);
            }

            rotateTimer = setTimeout(() => {
              openCandidate();
            }, rotateIntervalMs);
          }
        });

        res.on('end', () => {
          if (activeReq === req) {
            activeReq = null;
            scheduleRetry(500);
          } else if (!promoted && !settled) {
            settled = true;
            scheduleRetry(1500);
          }
        });

        res.on('error', () => {
          if (activeReq === req) {
            activeReq = null;
            scheduleRetry(500);
          } else if (!promoted && !settled) {
            settled = true;
            scheduleRetry(1500);
          }
        });
      }
    );

    const handshakeGuard = setTimeout(() => {
      if (!promoted) {
        settled = true;
        try { req.destroy(); } catch {}
        scheduleRetry(1500);
      }
    }, 12000);

    req.on('timeout', () => {
      if (!promoted) {
        settled = true;
        try { req.destroy(); } catch {}
        scheduleRetry(1500);
      }
    });

    req.on('error', () => {
      clearTimeout(handshakeGuard);
      if (activeReq === req) {
        activeReq = null;
        scheduleRetry(500);
      } else if (!promoted && !settled) {
        settled = true;
        scheduleRetry(1500);
      }
    });
  }

  openCandidate();
}

function sendNonPooledPing() {
  const req = https.get(
    PUBLIC_URL + '/api/keepalive?p=' + Date.now() + '_' + Math.random().toString(36).slice(2, 6),
    {
      agent: false,
      headers: {
        'Cache-Control': 'no-cache, no-store, must-revalidate',
        'Connection': 'close',
        'User-Agent': 'BoilerChemicalPing/3.0'
      },
      timeout: 8000
    },
    (res) => {
      res.resume();
    }
  );
  req.on('timeout', () => {
    try { req.destroy(); } catch {}
  });
  req.on('error', () => {});
}

let failCount = 0;
let spawningServer = false;
function checkLocalServer() {
  const req = http.get('http://127.0.0.1:3000/api/keepalive', { timeout: 2500 }, (res) => {
    res.resume();
    if (res.statusCode === 200) {
      failCount = 0;
    } else {
      failCount++;
    }
  });
  req.on('timeout', () => {
    try { req.destroy(); } catch {}
    failCount++;
  });
  req.on('error', () => {
    failCount++;
    if (failCount >= 3 && !spawningServer) {
      spawningServer = true;
      failCount = 0;
      try {
        const child = spawn('npm', ['run', 'dev', '--', '--port', '3000', '--host', '0.0.0.0'], {
          cwd: '/app/applet',
          detached: true,
          stdio: 'ignore',
        });
        child.unref();
      } catch {}
      setTimeout(() => { spawningServer = false; }, 15000);
    }
  });
}

setInterval(checkLocalServer, 3000);
setInterval(sendNonPooledPing, 5000);
sendNonPooledPing();
`;
    fs.writeFileSync(daemonScriptPath, daemonCode, 'utf-8');
    const child = spawn(process.execPath, [daemonScriptPath], {
      detached: true,
      stdio: 'ignore',
    });
    child.unref();
  } catch (_err) {
    // Ignore outside container environment
  }
}

function startAlwaysOnKeepAlive(): void {
  const maintainNonPooledStream = (endpointPath: string, slotId: number) => {
    let activeReq: http.ClientRequest | null = null;
    let rotateTimer: NodeJS.Timeout | null = null;
    let retryTimer: NodeJS.Timeout | null = null;
    const rotateIntervalMs = 135_000 + slotId * 17_000;

    const scheduleRetry = (delayMs: number) => {
      if (retryTimer) clearTimeout(retryTimer);
      retryTimer = setTimeout(() => {
        retryTimer = null;
        openCandidate();
      }, delayMs);
    };

    const openCandidate = () => {
      if (rotateTimer) {
        clearTimeout(rotateTimer);
        rotateTimer = null;
      }

      let promoted = false;
      let settled = false;
      const url = `${PUBLIC_APP_URL}${endpointPath}?slot=srv_${slotId}&t=${Date.now()}_${Math.random()
        .toString(36)
        .slice(2, 7)}`;

      const req = https.get(
        url,
        {
          agent: false,
          headers: {
            'Cache-Control': 'no-cache, no-store, must-revalidate',
            Pragma: 'no-cache',
            Accept: 'text/event-stream',
            Connection: 'keep-alive',
            'User-Agent': `BoilerChemicalServerKeepAlive/3.0 (slot-${slotId})`,
          },
          timeout: 15_000,
        },
        (res) => {
          if (res.statusCode !== 200) {
            res.resume();
            try {
              req.destroy();
            } catch (_e) {
              // Ignore
            }
            if (!settled) {
              settled = true;
              scheduleRetry(1500);
            }
            return;
          }

          res.on('data', () => {
            if (!promoted) {
              promoted = true;
              clearTimeout(handshakeGuard);
              const oldReq = activeReq;
              activeReq = req;

              if (oldReq && oldReq !== req) {
                setTimeout(() => {
                  try {
                    oldReq.destroy();
                  } catch (_e) {
                    // Ignore
                  }
                }, 6_000);
              }

              rotateTimer = setTimeout(() => {
                openCandidate();
              }, rotateIntervalMs);
            }
          });

          res.on('end', () => {
            if (activeReq === req) {
              activeReq = null;
              scheduleRetry(500);
            } else if (!promoted && !settled) {
              settled = true;
              scheduleRetry(1500);
            }
          });

          res.on('error', () => {
            if (activeReq === req) {
              activeReq = null;
              scheduleRetry(500);
            } else if (!promoted && !settled) {
              settled = true;
              scheduleRetry(1500);
            }
          });
        }
      );

      const handshakeGuard = setTimeout(() => {
        if (!promoted) {
          settled = true;
          try {
            req.destroy();
          } catch (_e) {
            // Ignore
          }
          scheduleRetry(1500);
        }
      }, 12_000);

      req.on('timeout', () => {
        if (!promoted) {
          settled = true;
          try {
            req.destroy();
          } catch (_e) {
            // Ignore
          }
          scheduleRetry(1500);
        }
      });

      req.on('error', () => {
        clearTimeout(handshakeGuard);
        if (activeReq === req) {
          activeReq = null;
          scheduleRetry(500);
        } else if (!promoted && !settled) {
          settled = true;
          scheduleRetry(1500);
        }
      });
    };

    openCandidate();
  };

  const sendPing = () => {
    ensurePublicAccessEnabled();
    ensureDaemonProcessRunning();
    const req = https.get(
      `${PUBLIC_APP_URL}/api/keepalive?t=${Date.now()}`,
      {
        agent: false,
        headers: {
          'Cache-Control': 'no-cache, no-store, must-revalidate',
          Connection: 'close',
        },
        timeout: 8_000,
      },
      (res) => {
        res.resume();
      }
    );
    req.on('timeout', () => {
      try {
        req.destroy();
      } catch (_e) {
        // Ignore
      }
    });
    req.on('error', () => {
      // Ignore transient network errors
    });
  };

  ensureDaemonProcessRunning();

  setTimeout(() => {
    sendPing();
    maintainNonPooledStream('/__keepalive_stream', 1);
    maintainNonPooledStream('/__keepalive_stream', 2);
    maintainNonPooledStream('/api/keepalive-stream', 3);
    maintainNonPooledStream('/api/keepalive-stream', 4);
  }, 500);

  setInterval(sendPing, 6_000);
}

async function startServer() {
  ensurePublicAccessEnabled();

  const app = express();
  app.use((req, res, next) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    if (req.method === 'OPTIONS') {
      return res.sendStatus(204);
    }
    next();
  });
  app.use(express.json({ limit: '5mb' }));
  app.use(express.static(path.join(process.cwd(), 'public')));

  app.get(['/__cookie_check.html', '/forbidden.html'], (_req, res) => {
    res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
    res.redirect(302, '/');
  });

  // Keepalive endpoints to prevent Cloud Run scale-to-zero when developer closes AI Studio
  app.get('/api/keepalive', (_req, res) => {
    ensurePublicAccessEnabled();
    res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
    res.json({ ok: true, ts: Date.now() });
  });

  app.get('/api/keepalive-stream', (req, res) => {
    ensurePublicAccessEnabled();
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
    res.setHeader('Connection', 'keep-alive');
    res.setHeader('X-Accel-Buffering', 'no');
    res.flushHeaders?.();
    res.write(`data: connected_${Date.now()}\n\n`);

    const interval = setInterval(() => {
      try {
        res.write(`data: ${Date.now()}\n\n`);
      } catch (_e) {
        clearInterval(interval);
      }
    }, 2_500);

    // Keep server-side stream open for up to 50 minutes (3,000,000 ms) so it never closes before replacement
    const maxDuration = setTimeout(() => {
      clearInterval(interval);
      try {
        res.end();
      } catch (_e) {
        // Ignore
      }
    }, 3_000_000);

    req.on('close', () => {
      clearInterval(interval);
      clearTimeout(maxDuration);
    });
  });

  // 1. GET full state (merges local + Supabase central DB)
  app.get('/api/state', async (_req, res) => {
    const db = loadDb();
    const { online, pinInitialized } = await syncFromSupabase(db);
    res.json({
      ok: true,
      supabaseOnline: online,
      supabaseUrl: SUPABASE_URL,
      settings: {
        ...db.settings,
        admin_pin: undefined,
        pin_initialized: pinInitialized,
        pin_length: 4,
      },
      boilers: db.boilers,
      chemicals: db.chemicals,
      history: db.history,
      audit_logs: db.audit_logs.slice(0, 30),
      serverTime: nowIso(),
    });
  });

  // 2. POST calculate & save record (Deduplicated + Supabase + Local + Google Sheet, zero data loss)
  app.post('/api/calculations', async (req, res) => {
    try {
      const db = loadDb();
      if (!db.settings.permissions.allow_calculate || !db.settings.permissions.allow_save) {
        return res.status(403).json({
          ok: false,
          error: 'ผู้ดูแลระบบปิดสิทธิ์การคำนวณหรือบันทึกข้อมูลไว้ใน Permission Center',
        });
      }

      const body = req.body as Partial<CalculationHistoryRecord>;
      const boilerName = normalizeBoilerDisplayName(String(body.boiler_name || ''));
      const recorderName = String(body.recorder_name || 'แผนกบอยเลอร์').trim();
      const cleanNote = typeof body.note === 'string' ? body.note.trim() : '';
      const rawDetails = Array.isArray(body.details) ? body.details : [];
      const details: CalculationDetailItem[] = rawDetails.map((d) => ({
        ...d,
        ...(cleanNote || d.note ? { note: String(d.note || cleanNote).trim() } : {}),
      }));

      if (!boilerName) {
        return res.status(400).json({ ok: false, error: 'กรุณาเลือก Boiler ก่อนทำการคำนวณและบันทึกข้อมูล' });
      }
      if (details.length === 0) {
        return res.status(400).json({
          ok: false,
          error: 'กรุณากรอกค่าล่าสุดและค่าปัจจุบันให้ครบอย่างน้อย 1 รายการสารเคมี',
        });
      }

      const clientRecordId =
        body.client_record_id ||
        `00000000-0000-4000-8000-${Math.random().toString(16).slice(2).padEnd(12, '0').slice(0, 12)}`;

      const oneMinuteAgo = Date.now() - 60 * 1000;
      const detailsSig = JSON.stringify(details);
      const duplicate = db.history.find(
        (h) =>
          h.client_record_id === clientRecordId ||
          (normalizeBoilerDisplayName(h.boiler_name).toLowerCase() === boilerName.toLowerCase() &&
            JSON.stringify(h.details) === detailsSig &&
            new Date(h.calculated_at).getTime() > oneMinuteAgo)
      );

      if (duplicate) {
        return res.status(409).json({
          ok: false,
          duplicate: true,
          error: 'ข้อมูลชุดนี้ถูกบันทึกไปแล้ว ระบบป้องกันการบันทึกข้อมูลซ้ำอัตโนมัติ',
          record: duplicate,
        });
      }

      const calculatedAt = body.calculated_at || nowIso();
      let remoteId = '';
      let syncedSupabase = false;

      try {
        const uuidBoilerId =
          body.boiler_id && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(body.boiler_id)
            ? body.boiler_id
            : null;

        const sbRes = await fetch(`${SUPABASE_URL}/rest/v1/calculation_history`, {
          method: 'POST',
          headers: {
            ...SB_HEADERS,
            Prefer: 'resolution=ignore-duplicates,return=representation',
          },
          body: JSON.stringify({
            client_record_id: clientRecordId,
            boiler_id: uuidBoilerId,
            boiler_name: boilerName,
            recorder_name: recorderName,
            calculated_at: calculatedAt,
            details: details.map((d) => ({
              name: d.name,
              report: d.report,
              curr: d.curr,
              ...(d.note || cleanNote ? { note: String(d.note || cleanNote).trim() } : {}),
            })),
          }),
        });

        if (sbRes.ok) {
          const inserted = await sbRes.json();
          const row = Array.isArray(inserted) ? inserted[0] : inserted;
          if (row?.id) remoteId = String(row.id);
          syncedSupabase = true;
        }
      } catch (sbErr) {
        console.warn('Supabase insert fallback to local store:', sbErr);
      }

      const newRecord: CalculationHistoryRecord = {
        id: remoteId || `calc_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
        client_record_id: clientRecordId,
        boiler_id: body.boiler_id || null,
        boiler_name: boilerName,
        recorder_name: recorderName,
        ...(cleanNote ? { note: cleanNote } : {}),
        calculated_at: calculatedAt,
        details,
        synced_supabase: syncedSupabase,
      };

      const deletedSet = new Set(db.deleted_history_ids || []);
      db.history = deduplicateHistory([newRecord, ...db.history], deletedSet);
      saveDb(db);

      await mirrorToGoogleSheet(db.settings.gas_webapp_url, 'ADD_CALCULATION', newRecord);

      return res.json({
        ok: true,
        syncedSupabase,
        record: newRecord,
        history: db.history,
      });
    } catch (err) {
      console.error('Error saving calculation:', err);
      return res.status(500).json({ ok: false, error: 'เกิดข้อผิดพลาดในการบันทึกข้อมูล' });
    }
  });

  // 3. DELETE calculation history record
  app.delete('/api/calculations/:id', async (req, res) => {
    try {
      const db = loadDb();
      const isAdmin = req.query.isAdmin === 'true';
      if (!isAdmin && !db.settings.permissions.allow_history_delete) {
        return res.status(403).json({
          ok: false,
          error: 'ผู้ดูแลระบบปิดสิทธิ์การลบประวัติไว้ใน Permission Center',
        });
      }

      const { id } = req.params;
      const target = db.history.find((h) => h.id === id || h.client_record_id === id);

      if (target) {
        if (/^[0-9a-f]{8}-[0-9a-f]{4}-/i.test(target.id)) {
          await callSupabaseRpc('delete_calculation_history', { p_id: target.id });
        }
        const delSet = new Set(db.deleted_history_ids || []);
        delSet.add(target.id);
        if (target.client_record_id) delSet.add(target.client_record_id);
        db.deleted_history_ids = Array.from(delSet);
      } else {
        const delSet = new Set(db.deleted_history_ids || []);
        delSet.add(id);
        db.deleted_history_ids = Array.from(delSet);
      }

      db.history = db.history.filter((h) => h.id !== id && h.client_record_id !== id);
      addAuditLog(db, 'DELETE_HISTORY', `ลบรายการประวัติ ${target?.boiler_name || id}`);
      saveDb(db);

      return res.json({ ok: true, history: db.history });
    } catch (err) {
      console.error('Delete calculation error:', err);
      return res.status(500).json({ ok: false, error: 'ไม่สามารถลบรายการประวัติได้' });
    }
  });

  // 4. POST Admin Login or First-Time Setup (Real Supabase RPC + Persistent DB)
  app.post('/api/admin/login', async (req, res) => {
    try {
      const db = loadDb();
      const pin = String(req.body?.pin || '').trim();
      const isSetup = Boolean(req.body?.setup);

      if (!/^\d{4}$/.test(pin)) {
        return res.status(400).json({ ok: false, error: 'กรุณาใส่รหัส Admin 4 หลัก' });
      }

      if (isSetup) {
        const sbSetup = await callSupabaseRpc('admin_setup_pin', { p_pin: pin, p_pin_length: 4 });
        const setupData = sbSetup.data as { ok?: boolean; session_token?: string; expires_at?: number } | null;
        db.settings.admin_pin = pin;
        db.settings.pin_initialized = true;
        addAuditLog(db, 'ADMIN_SETUP_PIN', 'ตั้งรหัส Admin PIN 4 หลักเรียบร้อยแล้ว');
        saveDb(db);
        return res.json({
          ok: true,
          sessionToken: setupData?.session_token || `sb_local_${Date.now()}`,
          expiresAt: setupData?.expires_at || Date.now() + 2 * 3600 * 1000,
        });
      }

      // 1) Verify against live Supabase admin_login RPC
      const sbLogin = await callSupabaseRpc('admin_login', { p_pin: pin });
      const loginData = sbLogin.data as {
        ok?: boolean;
        session_token?: string;
        expires_at?: number;
        message?: string;
      } | null;

      if (loginData?.ok && loginData.session_token) {
        db.settings.admin_pin = pin;
        db.settings.pin_initialized = true;
        addAuditLog(db, 'ADMIN_LOGIN', 'เข้าสู่ระบบผู้ดูแลระบบผ่านฐานข้อมูลกลางสำเร็จ');
        saveDb(db);
        return res.json({
          ok: true,
          sessionToken: loginData.session_token,
          expiresAt: loginData.expires_at || Date.now() + 2 * 3600 * 1000,
        });
      }

      // 2) Verify against stored local DB PIN if configured
      if (db.settings.admin_pin && pin === db.settings.admin_pin) {
        addAuditLog(db, 'ADMIN_LOGIN', 'เข้าสู่ระบบผู้ดูแลระบบสำเร็จ');
        saveDb(db);
        return res.json({
          ok: true,
          sessionToken: `admin_${Date.now()}`,
          expiresAt: Date.now() + 2 * 3600 * 1000,
        });
      }

      return res.status(401).json({
        ok: false,
        error: loginData?.message || 'รหัส Admin ไม่ถูกต้อง',
      });
    } catch (err) {
      return res.status(500).json({ ok: false, error: 'เกิดข้อผิดพลาดในการตรวจสอบรหัสผ่าน' });
    }
  });

  // 5. POST Admin Change PIN (Syncs with Supabase admin_change_pin RPC + Local DB)
  app.post('/api/admin/change-pin', async (req, res) => {
    try {
      const db = loadDb();
      const { oldPin, newPin, sessionToken } = req.body as {
        oldPin?: string;
        newPin?: string;
        sessionToken?: string;
      };

      if (!newPin || !/^\d{4}$/.test(newPin)) {
        return res.status(400).json({ ok: false, error: 'รหัส PIN ใหม่ต้องเป็นตัวเลข 4 หลัก' });
      }

      let activeToken = sessionToken || '';
      if (oldPin) {
        const sbLogin = await callSupabaseRpc('admin_login', { p_pin: oldPin });
        const loginData = sbLogin.data as { ok?: boolean; session_token?: string } | null;
        if (loginData?.ok && loginData.session_token) {
          activeToken = loginData.session_token;
        } else if (db.settings.admin_pin && oldPin !== db.settings.admin_pin) {
          return res.status(401).json({ ok: false, error: 'รหัส Admin เดิมไม่ถูกต้อง' });
        }
      }

      if (activeToken && !activeToken.startsWith('admin_')) {
        const sbChange = await callSupabaseRpc('admin_change_pin', {
          p_session_token: activeToken,
          p_old_pin: oldPin || db.settings.admin_pin,
          p_new_pin: newPin,
          p_pin_length: 4,
        });
        const changeData = sbChange.data as { ok?: boolean; message?: string } | null;
        if (changeData && changeData.ok === false) {
          return res.status(400).json({ ok: false, error: changeData.message || 'เปลี่ยนรหัสไม่สำเร็จ' });
        }
      }

      db.settings.admin_pin = newPin;
      db.settings.pin_initialized = true;
      db.settings.updated_at = nowIso();
      addAuditLog(db, 'CHANGE_PIN', 'เปลี่ยนรหัส Admin PIN 4 หลักในฐานข้อมูลกลางแล้ว');
      saveDb(db);

      return res.json({ ok: true, message: 'เปลี่ยนรหัส Admin PIN สำเร็จ' });
    } catch (err) {
      return res.status(500).json({ ok: false, error: 'ไม่สามารถเปลี่ยนรหัส PIN ได้' });
    }
  });

  // 6. PUT Settings & Permissions (Syncs with Supabase admin_set_setting & admin_set_permissions)
  app.put('/api/settings', async (req, res) => {
    try {
      const db = loadDb();
      const incoming = req.body as Partial<AppSettings> & { sessionToken?: string };
      const token = await ensureSupabaseSessionToken(db, incoming.sessionToken);

      if (incoming.site_name !== undefined && token) {
        await callSupabaseRpc('admin_set_setting', {
          p_session_token: token,
          p_key: 'site_name',
          p_value: { value: String(incoming.site_name).trim() },
        });
      }
      if (incoming.app_version !== undefined && token) {
        await callSupabaseRpc('admin_set_setting', {
          p_session_token: token,
          p_key: 'app_version',
          p_value: { value: String(incoming.app_version).trim() },
        });
      }
      if (incoming.preview_image_url !== undefined && token) {
        await callSupabaseRpc('admin_set_setting', {
          p_session_token: token,
          p_key: 'preview_image_url',
          p_value: { value: String(incoming.preview_image_url).trim() },
        });
      }
      if (incoming.permissions && token) {
        await callSupabaseRpc('admin_set_permissions', {
          p_session_token: token,
          p_permissions: incoming.permissions,
        });
      }

      db.settings = {
        ...db.settings,
        site_name: incoming.site_name !== undefined ? String(incoming.site_name).trim() : db.settings.site_name,
        app_version:
          incoming.app_version !== undefined ? String(incoming.app_version).trim() : db.settings.app_version,
        developer_name:
          incoming.developer_name !== undefined
            ? String(incoming.developer_name).trim()
            : db.settings.developer_name,
        copyright_name:
          incoming.copyright_name !== undefined
            ? String(incoming.copyright_name).trim()
            : db.settings.copyright_name,
        department_name:
          incoming.department_name !== undefined
            ? String(incoming.department_name).trim()
            : db.settings.department_name,
        announcement:
          incoming.announcement !== undefined ? String(incoming.announcement).trim() : db.settings.announcement,
        preview_image_url:
          incoming.preview_image_url !== undefined
            ? String(incoming.preview_image_url).trim()
            : db.settings.preview_image_url || '',
        gas_webapp_url:
          incoming.gas_webapp_url !== undefined
            ? String(incoming.gas_webapp_url).trim()
            : db.settings.gas_webapp_url,
        db_mode: incoming.db_mode || db.settings.db_mode,
        permissions: {
          ...db.settings.permissions,
          ...(incoming.permissions || {}),
        },
        updated_at: nowIso(),
      };

      addAuditLog(db, 'UPDATE_SETTINGS', `อัปเดตการตั้งค่าระบบ (${db.settings.site_name} v${db.settings.app_version})`);
      saveDb(db);

      await mirrorToGoogleSheet(db.settings.gas_webapp_url, 'UPDATE_SETTINGS', db.settings);

      return res.json({
        ok: true,
        settings: {
          ...db.settings,
          admin_pin: undefined,
        },
        audit_logs: db.audit_logs.slice(0, 30),
      });
    } catch (err) {
      return res.status(500).json({ ok: false, error: 'ไม่สามารถบันทึกการตั้งค่าได้' });
    }
  });

  // 7. POST Boilers (Syncs with Supabase admin_manage_boiler + Local DB)
  app.post('/api/boilers', async (req, res) => {
    const db = loadDb();
    const { id, name, active, action, sessionToken } = req.body as {
      id?: string;
      name?: string;
      active?: boolean;
      action?: 'add' | 'rename' | 'toggle' | 'delete';
      sessionToken?: string;
    };
    const token = await ensureSupabaseSessionToken(db, sessionToken);

    if ((action === 'delete' || action === 'toggle') && id) {
      if (db.boilers.filter((b) => b.active).length <= 1 && action === 'delete') {
        return res.status(400).json({ ok: false, error: 'ระบบจำเป็นต้องมี Boiler อย่างน้อย 1 รายการ' });
      }
      if (token) {
        await callSupabaseRpc('admin_manage_boiler', {
          p_session_token: token,
          p_action: 'disable',
          p_id: id,
        });
      }
      if (action === 'delete') {
        db.boilers = db.boilers.filter((b) => b.id !== id);
        addAuditLog(db, 'DELETE_BOILER', `ปิดใช้งาน/ลบ Boiler ID: ${id}`);
      } else {
        const target = db.boilers.find((b) => b.id === id);
        if (target) {
          if (target.active && db.boilers.filter((b) => b.active).length <= 1) {
            return res.status(400).json({ ok: false, error: 'ระบบจำเป็นต้องมี Boiler อย่างน้อย 1 รายการ' });
          }
          target.active = !target.active;
          addAuditLog(db, 'TOGGLE_BOILER', `${target.active ? 'เปิด' : 'ปิด'}ใช้งาน ${target.name}`);
        }
      }
      await syncFromSupabase(db);
      saveDb(db);
      return res.json({ ok: true, boilers: db.boilers, audit_logs: db.audit_logs.slice(0, 30) });
    }

    const cleanName = normalizeBoilerDisplayName(String(name || ''));
    if (!cleanName) {
      return res.status(400).json({ ok: false, error: 'กรุณาระบุชื่อ Boiler' });
    }

    if (id && action === 'rename') {
      if (token) {
        await callSupabaseRpc('admin_manage_boiler', {
          p_session_token: token,
          p_action: 'rename',
          p_id: id,
          p_name: cleanName,
        });
      }
      const target = db.boilers.find((b) => b.id === id);
      if (target) {
        target.name = cleanName;
        if (active !== undefined) target.active = Boolean(active);
        addAuditLog(db, 'UPDATE_BOILER', `แก้ไขชื่อ Boiler เป็น "${cleanName}"`);
      }
    } else {
      if (db.boilers.some((b) => normalizeBoilerDisplayName(b.name).toLowerCase() === cleanName.toLowerCase())) {
        return res.status(409).json({ ok: false, error: `มี "${cleanName}" อยู่ในระบบแล้ว` });
      }
      if (token) {
        await callSupabaseRpc('admin_manage_boiler', {
          p_session_token: token,
          p_action: 'add',
          p_name: cleanName,
        });
      }
      db.boilers.push({
        id: `boiler_${Date.now()}`,
        name: cleanName,
        active: true,
        sort_order: db.boilers.length + 1,
      });
      addAuditLog(db, 'ADD_BOILER', `เพิ่ม Boiler ใหม่ "${cleanName}"`);
    }

    await syncFromSupabase(db);
    saveDb(db);
    return res.json({ ok: true, boilers: db.boilers, audit_logs: db.audit_logs.slice(0, 30) });
  });

  // 8. POST Chemicals (Syncs with Supabase admin_manage_chemical + Local DB)
  app.post('/api/chemicals', async (req, res) => {
    const db = loadDb();
    const { id, code, name, divisor, unit, description, active, action, sessionToken } = req.body as {
      id?: string;
      code?: string;
      name?: string;
      divisor?: number;
      unit?: string;
      description?: string;
      active?: boolean;
      action?: 'add' | 'update' | 'toggle' | 'delete';
      sessionToken?: string;
    };
    const token = await ensureSupabaseSessionToken(db, sessionToken);

    if ((action === 'delete' || action === 'toggle') && id) {
      if (db.chemicals.filter((c) => c.active).length <= 1 && action === 'delete') {
        return res.status(400).json({ ok: false, error: 'ระบบจำเป็นต้องมีสารเคมีอย่างน้อย 1 รายการ' });
      }
      if (token) {
        await callSupabaseRpc('admin_manage_chemical', {
          p_session_token: token,
          p_action: 'disable',
          p_id: id,
        });
      }
      if (action === 'delete') {
        const target = db.chemicals.find((c) => c.id === id);
        db.chemicals = db.chemicals.filter((c) => c.id !== id);
        addAuditLog(db, 'DELETE_CHEMICAL', `ลบสารเคมี ${target?.name || id}`);
      } else {
        const target = db.chemicals.find((c) => c.id === id);
        if (target) {
          if (target.active && db.chemicals.filter((c) => c.active).length <= 1) {
            return res.status(400).json({ ok: false, error: 'ระบบจำเป็นต้องมีสารเคมีอย่างน้อย 1 รายการ' });
          }
          target.active = !target.active;
          addAuditLog(db, 'TOGGLE_CHEMICAL', `${target.active ? 'เปิด' : 'ปิด'}ใช้งานสารเคมี ${target.name}`);
        }
      }
      await syncFromSupabase(db);
      saveDb(db);
      return res.json({ ok: true, chemicals: db.chemicals, audit_logs: db.audit_logs.slice(0, 30) });
    }

    const cleanName = String(name || '').trim();
    const numDiv = Number(divisor);
    if (!cleanName || !Number.isFinite(numDiv) || numDiv <= 0) {
      return res.status(400).json({ ok: false, error: 'กรุณาระบุชื่อสารเคมีและตัวหารที่มากกว่า 0' });
    }

    if (id && action === 'update') {
      if (token) {
        await callSupabaseRpc('admin_manage_chemical', {
          p_session_token: token,
          p_action: 'update',
          p_id: id,
          p_name: cleanName,
          p_divisor: numDiv,
          p_unit: unit || 'L',
        });
      }
      const target = db.chemicals.find((c) => c.id === id);
      if (target) {
        target.name = cleanName;
        target.code = String(code || cleanName).trim();
        target.divisor = numDiv;
        target.unit = String(unit || target.unit || 'L').trim();
        if (description !== undefined) target.description = String(description).trim();
        if (active !== undefined) target.active = Boolean(active);
        addAuditLog(db, 'UPDATE_CHEMICAL', `แก้ไขสารเคมี ${cleanName} (÷ ${numDiv})`);
      }
    } else {
      if (db.chemicals.some((c) => c.name.toLowerCase() === cleanName.toLowerCase())) {
        return res.status(409).json({ ok: false, error: `มีสารเคมี "${cleanName}" อยู่ในระบบแล้ว` });
      }
      if (token) {
        await callSupabaseRpc('admin_manage_chemical', {
          p_session_token: token,
          p_action: 'add',
          p_name: cleanName,
          p_divisor: numDiv,
          p_unit: unit || 'L',
        });
      }
      const newChem: ChemicalConfig = {
        id: `chem_${Date.now()}`,
        code: String(code || cleanName).trim(),
        name: cleanName,
        divisor: numDiv,
        unit: String(unit || 'L').trim(),
        active: true,
        sort_order: db.chemicals.length + 1,
        description:
          String(description || '').trim() || `สารเคมีบอยเลอร์ ${cleanName} คำนวณปริมาณโดยหารด้วย ${numDiv}`,
      };
      db.chemicals.push(newChem);
      addAuditLog(db, 'ADD_CHEMICAL', `เพิ่มสารเคมีใหม่ ${cleanName} (÷ ${numDiv})`);
      await mirrorToGoogleSheet(db.settings.gas_webapp_url, 'UPSERT_CHEMICAL', newChem);
    }

    await syncFromSupabase(db);
    saveDb(db);
    return res.json({ ok: true, chemicals: db.chemicals, audit_logs: db.audit_logs.slice(0, 30) });
  });

  // 9. Explicit Download Endpoints (Forces browser attachment download even inside iframes)
  app.get('/api/download/:type', (req, res) => {
    const type = String(req.params.type || '').toLowerCase();
    const publicDir = path.join(process.cwd(), 'public');
    const distDir = path.join(process.cwd(), 'dist');

    const resolveAsset = (fileName: string) => {
      const p1 = path.join(publicDir, fileName);
      if (fs.existsSync(p1)) return p1;
      const p2 = path.join(distDir, fileName);
      if (fs.existsSync(p2)) return p2;
      return null;
    };

    if (type === 'index.html' || type === 'singlefile') {
      const filePath = resolveAsset('boiler-chemical-singlefile.html');
      if (filePath) {
        res.setHeader('Content-Type', 'application/octet-stream');
        res.setHeader('Content-Disposition', 'attachment; filename="index.html"');
        return res.sendFile(filePath);
      }
    }

    if (type === 'ready-web.zip' || type === 'boiler-chemical-ready-web.zip') {
      const filePath = resolveAsset('boiler-chemical-ready-web.zip');
      if (filePath) {
        res.setHeader('Content-Type', 'application/zip');
        res.setHeader('Content-Disposition', 'attachment; filename="boiler-chemical-ready-web.zip"');
        return res.sendFile(filePath);
      }
    }

    if (type === 'source-code.zip' || type === 'boiler-chemical-source-code.zip') {
      const filePath = resolveAsset('boiler-chemical-source-code.zip');
      if (filePath) {
        res.setHeader('Content-Type', 'application/zip');
        res.setHeader('Content-Disposition', 'attachment; filename="boiler-chemical-source-code.zip"');
        return res.sendFile(filePath);
      }
    }

    return res.status(404).send('File not found');
  });

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Boiler Chemical v3.0.0 Server running on http://0.0.0.0:${PORT}`);
    startAlwaysOnKeepAlive();
  });
}

startServer();
