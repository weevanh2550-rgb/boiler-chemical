import React, { createContext, useCallback, useContext, useEffect, useState } from 'react';
import {
  AppPermissions,
  AppSettings,
  AuditLogItem,
  BoilerOption,
  CalculationDetailItem,
  CalculationHistoryRecord,
  ChemicalConfig,
  ToastNotice,
} from '../types/boiler';

interface BoilerContextValue {
  settings: AppSettings;
  boilers: BoilerOption[];
  chemicals: ChemicalConfig[];
  history: CalculationHistoryRecord[];
  auditLogs: AuditLogItem[];
  supabaseOnline: boolean;
  supabaseUrl: string;
  isLoading: boolean;
  loadingMessage: string;
  toasts: ToastNotice[];
  adminUnlocked: boolean;
  adminSessionToken: string;
  hasUnreadHistory: boolean;
  markHistoryRead: () => void;
  showToast: (title: string, message?: string, type?: 'success' | 'error' | 'info') => void;
  dismissToast: (id: string) => void;
  refreshState: (showSpinner?: boolean) => Promise<void>;
  getLatestLevelForBoiler: (boilerName: string, chemicalName: string) => number | null;
  submitCalculation: (payload: {
    boiler_id: string | null;
    boiler_name: string;
    recorder_name: string;
    note?: string;
    details: CalculationDetailItem[];
  }) => Promise<{ ok: boolean; record?: CalculationHistoryRecord; error?: string }>;
  deleteHistoryRecord: (id: string) => Promise<boolean>;
  loginAdmin: (pin: string, setup?: boolean) => Promise<{ ok: boolean; error?: string }>;
  logoutAdmin: () => void;
  changeAdminPin: (oldPin: string, newPin: string) => Promise<{ ok: boolean; error?: string }>;
  saveAppSettings: (partial: Partial<AppSettings>) => Promise<boolean>;
  togglePermission: (key: keyof AppPermissions) => Promise<boolean>;
  manageBoiler: (payload: {
    id?: string;
    name?: string;
    active?: boolean;
    action?: 'add' | 'rename' | 'toggle' | 'delete';
  }) => Promise<boolean>;
  manageChemical: (payload: {
    id?: string;
    code?: string;
    name?: string;
    divisor?: number;
    unit?: string;
    description?: string;
    active?: boolean;
    action?: 'add' | 'update' | 'toggle' | 'delete';
  }) => Promise<boolean>;
}

const DEFAULT_SETTINGS: AppSettings = {
  site_name: 'Boiler Chemical',
  app_version: '3.0.0',
  developer_name: 'Weevanh Khambounheuang',
  copyright_name: 'Weevanh Khambounheuang',
  department_name: 'แผนกบอยเลอร์ (Steam Boiler Department)',
  announcement: '',
  preview_image_url: '',
  gas_webapp_url: '',
  db_mode: 'HYBRID_SUPABASE',
  permissions: {
    allow_calculate: true,
    allow_save: true,
    allow_history_view: true,
    allow_history_delete: true,
    allow_share: true,
    allow_chemical_info: true,
  },
  pin_initialized: true,
  pin_length: 4,
  updated_at: new Date().toISOString(),
};

const BoilerContext = createContext<BoilerContextValue | undefined>(undefined);

const DIRECT_SUPABASE_URL = 'https://yikekymtticqabnlsmdo.supabase.co';
const DIRECT_SUPABASE_KEY = 'sb_publishable_UY0NZTIxVQ7kF69iReLrLA_Cm6DcbsA';
const DIRECT_SB_HEADERS = {
  apikey: DIRECT_SUPABASE_KEY,
  Authorization: `Bearer ${DIRECT_SUPABASE_KEY}`,
  'Content-Type': 'application/json',
};

const LAST_SEEN_HISTORY_KEY = 'boiler_chem_v3_last_seen_history';
const ADMIN_TOKEN_KEY = 'boiler_chem_v3_admin_token';
const ADMIN_EXP_KEY = 'boiler_chem_v3_admin_exp';

export const BoilerProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [settings, setSettings] = useState<AppSettings>(DEFAULT_SETTINGS);
  const [boilers, setBoilers] = useState<BoilerOption[]>([
    { id: 'd76e193b-903b-4b22-a0af-654b948f4218', name: 'Boiler #1-2', active: true, sort_order: 1 },
    { id: '437f1304-d144-452a-9a0c-d2b71b1e8ec3', name: 'Boiler #3', active: true, sort_order: 2 },
  ]);
  const [chemicals, setChemicals] = useState<ChemicalConfig[]>([
    { id: 'ea1a770f-3c27-4a6c-8f00-367f0c43eeda', code: 'MCC-N', name: 'MCC-N', divisor: 4, unit: 'L', active: true, sort_order: 1 },
    { id: 'e0c5af2a-8d06-44ef-82e0-8d2267463337', code: 'POLY-SRB', name: 'PolyTreat-SRB', divisor: 4, unit: 'L', active: true, sort_order: 2 },
    { id: 'b71673f0-d26d-44e6-bcab-660d1e8cc25a', code: 'TCE-2138', name: 'TCE-2138', divisor: 8, unit: 'L', active: true, sort_order: 3 },
  ]);
  const [history, setHistory] = useState<CalculationHistoryRecord[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLogItem[]>([]);
  const [supabaseOnline, setSupabaseOnline] = useState<boolean>(true);
  const [supabaseUrl, setSupabaseUrl] = useState<string>(DIRECT_SUPABASE_URL);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [loadingMessage, setLoadingMessage] = useState<string>('กำลังซิงก์ฐานข้อมูล...');
  const [toasts, setToasts] = useState<ToastNotice[]>([]);
  const [adminSessionToken, setAdminSessionToken] = useState<string>(() => {
    const token = sessionStorage.getItem(ADMIN_TOKEN_KEY) || '';
    const exp = Number(sessionStorage.getItem(ADMIN_EXP_KEY) || 0);
    return token && Date.now() < exp ? token : '';
  });
  const [hasUnreadHistory, setHasUnreadHistory] = useState<boolean>(false);

  const adminUnlocked = Boolean(adminSessionToken);

  const dismissToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  const showToast = useCallback(
    (title: string, message = '', type?: 'success' | 'error' | 'info') => {
      const resolvedType: 'success' | 'error' | 'info' =
        type ||
        (/(สำเร็จ|เรียบร้อย|คัดลอก|บันทึกแล้ว|อัปเดต)/.test(title)
          ? 'success'
          : /(ผิดพลาด|ไม่สำเร็จ|ไม่ถูกต้อง|ไม่ครบ|ปิดไว้|ไม่สามารถ)/.test(title)
          ? 'error'
          : 'info');

      const id = `toast_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
      setToasts((prev) => [...prev.slice(-3), { id, type: resolvedType, title, message }]);
      setTimeout(() => {
        dismissToast(id);
      }, 2500);
    },
    [dismissToast]
  );

  const checkUnreadBadge = useCallback((records: CalculationHistoryRecord[]) => {
    if (!records.length) {
      setHasUnreadHistory(false);
      return;
    }
    const latestId = records[0].id;
    const lastSeen = localStorage.getItem(LAST_SEEN_HISTORY_KEY);
    if (!lastSeen) {
      localStorage.setItem(LAST_SEEN_HISTORY_KEY, latestId);
      setHasUnreadHistory(false);
    } else {
      setHasUnreadHistory(lastSeen !== latestId);
    }
  }, []);

  const markHistoryRead = useCallback(() => {
    if (history.length > 0) {
      localStorage.setItem(LAST_SEEN_HISTORY_KEY, history[0].id);
    }
    setHasUnreadHistory(false);
  }, [history]);

  const fetchDirectFromSupabase = useCallback(async () => {
    try {
      const [boilerRes, chemRes, histRes, sysRes] = await Promise.all([
        fetch(`${DIRECT_SUPABASE_URL}/rest/v1/boilers?select=*&order=sort_order.asc`, {
          headers: DIRECT_SB_HEADERS,
        }),
        fetch(`${DIRECT_SUPABASE_URL}/rest/v1/chemicals?select=*&order=sort_order.asc`, {
          headers: DIRECT_SB_HEADERS,
        }),
        fetch(
          `${DIRECT_SUPABASE_URL}/rest/v1/calculation_history?select=*&order=calculated_at.desc&limit=5000`,
          { headers: DIRECT_SB_HEADERS }
        ),
        fetch(`${DIRECT_SUPABASE_URL}/rest/v1/system_settings?select=setting_key,setting_value`, {
          headers: DIRECT_SB_HEADERS,
        }),
      ]);

      if (boilerRes.ok) {
        const bRows = await boilerRes.json();
        if (Array.isArray(bRows) && bRows.length > 0) {
          const active = bRows
            .filter((b: Record<string, unknown>) => b && b.name && b.active !== false)
            .map((b: Record<string, unknown>, i: number) => ({
              id: String(b.id),
              name: String(b.name),
              active: true,
              sort_order: Number(b.sort_order ?? i + 1),
            }));
          if (active.length > 0) setBoilers(active);
        }
      }

      if (chemRes.ok) {
        const cRows = await chemRes.json();
        if (Array.isArray(cRows) && cRows.length > 0) {
          const active = cRows
            .filter((c: Record<string, unknown>) => c && c.name && c.active !== false)
            .map((c: Record<string, unknown>, i: number) => ({
              id: String(c.id),
              code: String(c.code || c.name),
              name: String(c.name),
              divisor: Number(c.divisor) || 4,
              unit: String(c.unit || 'L'),
              active: true,
              sort_order: Number(c.sort_order ?? i + 1),
            }));
          if (active.length > 0) setChemicals(active);
        }
      }

      if (histRes.ok) {
        const hRows = await histRes.json();
        if (Array.isArray(hRows)) {
          const mapped: CalculationHistoryRecord[] = hRows.map((rh: Record<string, unknown>) => {
            const rawDetails = Array.isArray(rh.details) ? (rh.details as CalculationDetailItem[]) : [];
            const extractedNote =
              typeof rh.note === 'string' && rh.note.trim()
                ? rh.note.trim()
                : rawDetails.find((d) => typeof d?.note === 'string' && d.note.trim())?.note?.trim() || '';
            return {
              id: String(rh.id),
              client_record_id: String(rh.client_record_id || rh.id),
              boiler_id: rh.boiler_id ? String(rh.boiler_id) : null,
              boiler_name: String(rh.boiler_name || 'Boiler'),
              recorder_name: String(rh.recorder_name || 'แผนกบอยเลอร์'),
              ...(extractedNote ? { note: extractedNote } : {}),
              calculated_at: String(rh.calculated_at || rh.created_at || new Date().toISOString()),
              details: rawDetails,
              synced_supabase: true,
            };
          });
          setHistory(mapped);
          checkUnreadBadge(mapped);
        }
      }

      if (sysRes.ok) {
        const sRows = await sysRes.json();
        if (Array.isArray(sRows)) {
          setSettings((prev) => {
            const next = { ...prev, permissions: { ...prev.permissions } };
            for (const row of sRows) {
              const key = String(row?.setting_key || '');
              const valObj = row?.setting_value as Record<string, unknown> | undefined;
              if (key === 'site_name' && typeof valObj?.value === 'string' && valObj.value.trim()) {
                next.site_name = valObj.value.trim();
              } else if (
                key === 'app_version' &&
                typeof valObj?.value === 'string' &&
                valObj.value.trim()
              ) {
                next.app_version = valObj.value.trim();
              } else if (
                key === 'preview_image_url' &&
                typeof valObj?.value === 'string'
              ) {
                next.preview_image_url = valObj.value.trim();
              } else if (key === 'permissions' && valObj && typeof valObj === 'object') {
                next.permissions = {
                  ...next.permissions,
                  ...(valObj as Partial<AppPermissions>),
                };
              }
            }
            return next;
          });
        }
      }

      setSupabaseOnline(true);
    } catch (err) {
      console.warn('Direct Supabase fallback error:', err);
    }
  }, [checkUnreadBadge]);

  const refreshState = useCallback(
    async (showSpinner = false) => {
      if (showSpinner) {
        setIsLoading(true);
        setLoadingMessage('กำลังโหลดข้อมูลจากฐานข้อมูลกลาง...');
      }
      try {
        const res = await fetch('/api/state');
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const data = await res.json();
        if (data?.ok) {
          if (data.settings) setSettings(data.settings);
          if (Array.isArray(data.boilers)) setBoilers(data.boilers);
          if (Array.isArray(data.chemicals)) setChemicals(data.chemicals);
          if (Array.isArray(data.history)) {
            setHistory(data.history);
            checkUnreadBadge(data.history);
          }
          if (Array.isArray(data.audit_logs)) setAuditLogs(data.audit_logs);
          setSupabaseOnline(Boolean(data.supabaseOnline));
          if (data.supabaseUrl) setSupabaseUrl(data.supabaseUrl);
          return;
        }
      } catch (_err) {
        await fetchDirectFromSupabase();
      } finally {
        if (showSpinner) {
          setTimeout(() => setIsLoading(false), 300);
        }
      }
    },
    [checkUnreadBadge, fetchDirectFromSupabase]
  );

  useEffect(() => {
    refreshState(true);
    const interval = setInterval(() => {
      refreshState(false);
    }, 8000);
    const handleVisibility = () => {
      if (document.visibilityState === 'visible') {
        refreshState(false);
      }
    };
    window.addEventListener('focus', handleVisibility);
    document.addEventListener('visibilitychange', handleVisibility);
    return () => {
      clearInterval(interval);
      window.removeEventListener('focus', handleVisibility);
      document.removeEventListener('visibilitychange', handleVisibility);
    };
  }, [refreshState]);

  const getLatestLevelForBoiler = useCallback(
    (boilerName: string, chemicalName: string): number | null => {
      if (!boilerName || !chemicalName) return null;
      const targetBoiler = boilerName.replace(/\s+/g, '').toLowerCase();
      const targetChem = chemicalName.trim().toLowerCase();

      for (const rec of history) {
        if (rec.boiler_name.replace(/\s+/g, '').toLowerCase() === targetBoiler) {
          const found = (rec.details || []).find(
            (d) => d.name.trim().toLowerCase() === targetChem
          );
          if (found && Number.isFinite(Number(found.curr))) {
            return Number(found.curr);
          }
        }
      }
      return null;
    },
    [history]
  );

  const submitCalculation = useCallback(
    async (payload: {
      boiler_id: string | null;
      boiler_name: string;
      recorder_name: string;
      note?: string;
      details: CalculationDetailItem[];
    }) => {
      setIsLoading(true);
      setLoadingMessage('กำลังคำนวณและบันทึกข้อมูล...');
      const client_record_id =
        typeof crypto !== 'undefined' && crypto.randomUUID
          ? crypto.randomUUID()
          : `00000000-0000-4000-8000-${Math.random().toString(16).slice(2).padEnd(12, '0').slice(0, 12)}`;
      const calculated_at = new Date().toISOString();
      const cleanNote = typeof payload.note === 'string' ? payload.note.trim() : '';

      try {
        const res = await fetch('/api/calculations', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            ...payload,
            ...(cleanNote ? { note: cleanNote } : {}),
            client_record_id,
            calculated_at,
          }),
        });
        const contentType = res.headers.get('content-type') || '';
        if (res.status === 404 || res.status === 405 || !contentType.includes('application/json')) {
          throw new Error('Static host fallback');
        }
        const data = await res.json();
        if (!res.ok || !data.ok) {
          showToast('บันทึกไม่สำเร็จ', data?.error || 'ไม่สามารถบันทึกผลการคำนวณได้', 'error');
          return { ok: false, error: data?.error };
        }
        if (Array.isArray(data.history)) {
          setHistory(data.history);
          checkUnreadBadge(data.history);
        }
        showToast('บันทึกสำเร็จ', `บันทึกข้อมูล ${payload.boiler_name} เรียบร้อยแล้ว`, 'success');
        return { ok: true, record: data.record };
      } catch (_err) {
        try {
          const uuidBoilerId =
            payload.boiler_id &&
            /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(payload.boiler_id)
              ? payload.boiler_id
              : null;

          const sbRes = await fetch(`${DIRECT_SUPABASE_URL}/rest/v1/calculation_history`, {
            method: 'POST',
            headers: {
              ...DIRECT_SB_HEADERS,
              Prefer: 'resolution=ignore-duplicates,return=representation',
            },
            body: JSON.stringify({
              client_record_id,
              boiler_id: uuidBoilerId,
              boiler_name: payload.boiler_name,
              recorder_name: payload.recorder_name || 'แผนกบอยเลอร์',
              calculated_at,
              details: payload.details.map((d) => ({
                name: d.name,
                report: d.report,
                curr: d.curr,
                ...(d.note || cleanNote ? { note: String(d.note || cleanNote).trim() } : {}),
              })),
            }),
          });
          if (sbRes.ok) {
            const inserted = await sbRes.json();
            const row = Array.isArray(inserted) ? inserted[0] : inserted;
            const record: CalculationHistoryRecord = {
              id: String(row?.id || client_record_id),
              client_record_id,
              boiler_id: payload.boiler_id,
              boiler_name: payload.boiler_name,
              recorder_name: payload.recorder_name || 'แผนกบอยเลอร์',
              ...(cleanNote ? { note: cleanNote } : {}),
              calculated_at,
              details: payload.details.map((d) => ({
                ...d,
                ...(d.note || cleanNote ? { note: String(d.note || cleanNote).trim() } : {}),
              })),
              synced_supabase: true,
            };
            await fetchDirectFromSupabase();
            showToast('บันทึกสำเร็จ', `บันทึกข้อมูล ${payload.boiler_name} เรียบร้อยแล้ว`, 'success');
            return { ok: true, record };
          }
        } catch (_sbErr) {
          // Ignore and show error toast below
        }
        showToast('เกิดข้อผิดพลาด', 'ไม่สามารถเชื่อมต่อฐานข้อมูลได้', 'error');
        return { ok: false, error: 'Network error' };
      } finally {
        setIsLoading(false);
      }
    },
    [checkUnreadBadge, fetchDirectFromSupabase, showToast]
  );

  const callDirectSupabaseRpc = useCallback(
    async (name: string, payload: Record<string, unknown> = {}) => {
      const res = await fetch(`${DIRECT_SUPABASE_URL}/rest/v1/rpc/${name}`, {
        method: 'POST',
        headers: DIRECT_SB_HEADERS,
        body: JSON.stringify(payload),
      });
      const data = await res.json().catch(() => null);
      return { ok: res.ok, status: res.status, data };
    },
    []
  );

  const deleteHistoryRecord = useCallback(
    async (id: string) => {
      setIsLoading(true);
      setLoadingMessage('กำลังลบรายการประวัติ...');
      try {
        const res = await fetch(`/api/calculations/${encodeURIComponent(id)}?isAdmin=${adminUnlocked}`, {
          method: 'DELETE',
        });
        const contentType = res.headers.get('content-type') || '';
        if (res.status === 404 || res.status === 405 || !contentType.includes('application/json')) {
          throw new Error('Static host fallback');
        }
        const data = await res.json();
        if (!res.ok || !data.ok) {
          showToast('ลบรายการไม่สำเร็จ', data?.error || 'ไม่มีสิทธิ์ลบรายการนี้', 'error');
          return false;
        }
        if (Array.isArray(data.history)) {
          setHistory(data.history);
        }
        showToast('ลบรายการสำเร็จ', 'ลบเฉพาะรายการที่เลือกจากฐานข้อมูลกลางแล้ว', 'success');
        return true;
      } catch (_err) {
        try {
          if (!adminUnlocked && !settings.permissions.allow_history_delete) {
            showToast('ลบรายการไม่สำเร็จ', 'ผู้ดูแลระบบปิดสิทธิ์การลบประวัติไว้ใน Permission Center', 'error');
            return false;
          }
          const rpc = await callDirectSupabaseRpc('delete_calculation_history', { p_id: id });
          if (rpc.ok) {
            setHistory((prev) => prev.filter((h) => h.id !== id && h.client_record_id !== id));
            showToast('ลบรายการสำเร็จ', 'ลบเฉพาะรายการที่เลือกจากฐานข้อมูลกลางแล้ว', 'success');
            return true;
          }
        } catch (_sbErr) {
          // Ignore and show error toast below
        }
        showToast('ลบรายการไม่สำเร็จ', 'เกิดข้อผิดพลาดในการเชื่อมต่อฐานข้อมูล', 'error');
        return false;
      } finally {
        setIsLoading(false);
      }
    },
    [adminUnlocked, callDirectSupabaseRpc, settings.permissions.allow_history_delete, showToast]
  );

  const loginAdmin = useCallback(
    async (pin: string, setup = false) => {
      setIsLoading(true);
      setLoadingMessage('กำลังตรวจสอบรหัสผู้ดูแลระบบ...');
      try {
        const res = await fetch('/api/admin/login', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ pin, setup }),
        });
        const contentType = res.headers.get('content-type') || '';
        if (res.status === 404 || res.status === 405 || !contentType.includes('application/json')) {
          throw new Error('Static host fallback');
        }
        const data = await res.json();
        if (!res.ok || !data.ok) {
          showToast('รหัสไม่ถูกต้อง', data?.error || 'กรุณาตรวจสอบรหัส Admin 4 หลัก', 'error');
          return { ok: false, error: data?.error };
        }
        const token = data.sessionToken || `admin_${Date.now()}`;
        const exp = data.expiresAt || Date.now() + 2 * 3600 * 1000;
        sessionStorage.setItem(ADMIN_TOKEN_KEY, token);
        sessionStorage.setItem(ADMIN_EXP_KEY, String(exp));
        setAdminSessionToken(token);
        await refreshState(false);
        return { ok: true };
      } catch (_err) {
        try {
          const rpcName = setup ? 'admin_setup_pin' : 'admin_login';
          const rpcPayload = setup ? { p_pin: pin, p_pin_length: 4 } : { p_pin: pin };
          const rpc = await callDirectSupabaseRpc(rpcName, rpcPayload);
          const loginData = rpc.data as { ok?: boolean; session_token?: string; message?: string } | null;
          if (rpc.ok && loginData?.ok && loginData.session_token) {
            const token = loginData.session_token;
            const exp = Date.now() + 2 * 3600 * 1000;
            sessionStorage.setItem(ADMIN_TOKEN_KEY, token);
            sessionStorage.setItem(ADMIN_EXP_KEY, String(exp));
            setAdminSessionToken(token);
            await fetchDirectFromSupabase();
            return { ok: true };
          }
          showToast('รหัสไม่ถูกต้อง', loginData?.message || 'กรุณาตรวจสอบรหัส Admin 4 หลัก', 'error');
          return { ok: false, error: loginData?.message || 'Invalid PIN' };
        } catch (_sbErr) {
          showToast('เกิดข้อผิดพลาด', 'ไม่สามารถตรวจสอบรหัส Admin ได้', 'error');
          return { ok: false, error: 'Network error' };
        }
      } finally {
        setIsLoading(false);
      }
    },
    [callDirectSupabaseRpc, fetchDirectFromSupabase, refreshState, showToast]
  );

  const logoutAdmin = useCallback(() => {
    sessionStorage.removeItem(ADMIN_TOKEN_KEY);
    sessionStorage.removeItem(ADMIN_EXP_KEY);
    setAdminSessionToken('');
  }, []);

  const changeAdminPin = useCallback(
    async (oldPin: string, newPin: string) => {
      setIsLoading(true);
      setLoadingMessage('กำลังบันทึกรหัส Admin ใหม่...');
      try {
        const res = await fetch('/api/admin/change-pin', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ oldPin, newPin, sessionToken: adminSessionToken }),
        });
        const contentType = res.headers.get('content-type') || '';
        if (res.status === 404 || res.status === 405 || !contentType.includes('application/json')) {
          throw new Error('Static host fallback');
        }
        const data = await res.json();
        if (!res.ok || !data.ok) {
          showToast('เปลี่ยนรหัสไม่สำเร็จ', data?.error || 'กรุณาตรวจสอบรหัสเดิมอีกครั้ง', 'error');
          return { ok: false, error: data?.error };
        }
        showToast('เปลี่ยน PIN สำเร็จ', 'รหัส Admin ใหม่ถูกบันทึกในฐานข้อมูลกลางแล้ว', 'success');
        return { ok: true };
      } catch (_err) {
        try {
          const rpc = await callDirectSupabaseRpc('admin_change_pin', {
            p_session_token: adminSessionToken,
            p_old_pin: oldPin,
            p_new_pin: newPin,
            p_pin_length: 4,
          });
          const changeData = rpc.data as { ok?: boolean; message?: string } | null;
          if (rpc.ok && changeData?.ok !== false) {
            showToast('เปลี่ยน PIN สำเร็จ', 'รหัส Admin ใหม่ถูกบันทึกในฐานข้อมูลกลางแล้ว', 'success');
            return { ok: true };
          }
          showToast('เปลี่ยนรหัสไม่สำเร็จ', changeData?.message || 'กรุณาตรวจสอบรหัสเดิมอีกครั้ง', 'error');
          return { ok: false, error: changeData?.message };
        } catch (_sbErr) {
          showToast('เปลี่ยนรหัสไม่สำเร็จ', 'เกิดข้อผิดพลาดในการเชื่อมต่อ', 'error');
          return { ok: false, error: 'Network error' };
        }
      } finally {
        setIsLoading(false);
      }
    },
    [adminSessionToken, callDirectSupabaseRpc, showToast]
  );

  const saveAppSettings = useCallback(
    async (partial: Partial<AppSettings>) => {
      setIsLoading(true);
      setLoadingMessage('กำลังบันทึกการตั้งค่าระบบ...');
      try {
        const res = await fetch('/api/settings', {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ ...partial, sessionToken: adminSessionToken }),
        });
        const contentType = res.headers.get('content-type') || '';
        if (res.status === 404 || res.status === 405 || !contentType.includes('application/json')) {
          throw new Error('Static host fallback');
        }
        const data = await res.json();
        if (!res.ok || !data.ok) {
          showToast('บันทึกไม่สำเร็จ', data?.error || 'เกิดข้อผิดพลาด', 'error');
          return false;
        }
        if (data.settings) setSettings(data.settings);
        if (Array.isArray(data.audit_logs)) setAuditLogs(data.audit_logs);
        showToast('บันทึกสำเร็จ', 'ข้อมูลถูกบันทึกในฐานข้อมูลกลางแล้ว', 'success');
        return true;
      } catch (_err) {
        try {
          if (partial.site_name !== undefined) {
            await callDirectSupabaseRpc('admin_set_setting', {
              p_session_token: adminSessionToken,
              p_key: 'site_name',
              p_value: { value: String(partial.site_name).trim() },
            });
          }
          if (partial.app_version !== undefined) {
            await callDirectSupabaseRpc('admin_set_setting', {
              p_session_token: adminSessionToken,
              p_key: 'app_version',
              p_value: { value: String(partial.app_version).trim() },
            });
          }
          if (partial.preview_image_url !== undefined) {
            await callDirectSupabaseRpc('admin_set_setting', {
              p_session_token: adminSessionToken,
              p_key: 'preview_image_url',
              p_value: { value: String(partial.preview_image_url).trim() },
            });
          }
          if (partial.permissions) {
            await callDirectSupabaseRpc('admin_set_permissions', {
              p_session_token: adminSessionToken,
              p_permissions: partial.permissions,
            });
          }
          setSettings((prev) => ({
            ...prev,
            ...partial,
            permissions: {
              ...prev.permissions,
              ...(partial.permissions || {}),
            },
            updated_at: new Date().toISOString(),
          }));
          await fetchDirectFromSupabase();
          showToast('บันทึกสำเร็จ', 'ข้อมูลถูกบันทึกในฐานข้อมูลกลางแล้ว', 'success');
          return true;
        } catch (_sbErr) {
          showToast('บันทึกไม่สำเร็จ', 'ไม่สามารถเชื่อมต่อฐานข้อมูลได้', 'error');
          return false;
        }
      } finally {
        setIsLoading(false);
      }
    },
    [adminSessionToken, callDirectSupabaseRpc, fetchDirectFromSupabase, showToast]
  );

  const togglePermission = useCallback(
    async (key: keyof AppPermissions) => {
      const nextPermissions: AppPermissions = {
        ...settings.permissions,
        [key]: !settings.permissions[key],
      };
      setSettings((prev) => ({ ...prev, permissions: nextPermissions }));
      try {
        const res = await fetch('/api/settings', {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ permissions: nextPermissions, sessionToken: adminSessionToken }),
        });
        const contentType = res.headers.get('content-type') || '';
        if (res.status === 404 || res.status === 405 || !contentType.includes('application/json')) {
          throw new Error('Static host fallback');
        }
        const data = await res.json();
        if (!res.ok || !data.ok) {
          setSettings((prev) => ({ ...prev, permissions: settings.permissions }));
          showToast('เปลี่ยนสิทธิ์ไม่สำเร็จ', data?.error || 'เกิดข้อผิดพลาด', 'error');
          return false;
        }
        if (data.settings) setSettings(data.settings);
        if (Array.isArray(data.audit_logs)) setAuditLogs(data.audit_logs);
        return true;
      } catch (_err) {
        try {
          const rpc = await callDirectSupabaseRpc('admin_set_permissions', {
            p_session_token: adminSessionToken,
            p_permissions: nextPermissions,
          });
          if (rpc.ok) {
            await fetchDirectFromSupabase();
            return true;
          }
        } catch (_sbErr) {
          // Fallback error below
        }
        setSettings((prev) => ({ ...prev, permissions: settings.permissions }));
        showToast('เปลี่ยนสิทธิ์ไม่สำเร็จ', 'เกิดข้อผิดพลาดในการเชื่อมต่อ', 'error');
        return false;
      }
    },
    [adminSessionToken, callDirectSupabaseRpc, fetchDirectFromSupabase, settings.permissions, showToast]
  );

  const manageBoiler = useCallback(
    async (payload: {
      id?: string;
      name?: string;
      active?: boolean;
      action?: 'add' | 'rename' | 'toggle' | 'delete';
    }) => {
      setIsLoading(true);
      setLoadingMessage('กำลังอัปเดตข้อมูล Boiler...');
      try {
        const res = await fetch('/api/boilers', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ ...payload, sessionToken: adminSessionToken }),
        });
        const contentType = res.headers.get('content-type') || '';
        if (res.status === 404 || res.status === 405 || !contentType.includes('application/json')) {
          throw new Error('Static host fallback');
        }
        const data = await res.json();
        if (!res.ok || !data.ok) {
          showToast('ดำเนินการไม่สำเร็จ', data?.error || 'ไม่สามารถอัปเดต Boiler ได้', 'error');
          return false;
        }
        if (Array.isArray(data.boilers)) setBoilers(data.boilers);
        if (Array.isArray(data.audit_logs)) setAuditLogs(data.audit_logs);
        showToast('บันทึกสำเร็จ', 'ข้อมูล Boiler ถูกบันทึกในฐานข้อมูลกลางแล้ว', 'success');
        return true;
      } catch (_err) {
        try {
          const sbAction =
            payload.action === 'delete' || payload.action === 'toggle'
              ? 'disable'
              : payload.action === 'rename'
              ? 'rename'
              : 'add';
          const rpc = await callDirectSupabaseRpc('admin_manage_boiler', {
            p_session_token: adminSessionToken,
            p_action: sbAction,
            ...(payload.id ? { p_id: payload.id } : {}),
            ...(payload.name ? { p_name: payload.name.trim() } : {}),
          });
          if (rpc.ok) {
            await fetchDirectFromSupabase();
            showToast('บันทึกสำเร็จ', 'ข้อมูล Boiler ถูกบันทึกในฐานข้อมูลกลางแล้ว', 'success');
            return true;
          }
        } catch (_sbErr) {
          // Ignore and show error below
        }
        showToast('ดำเนินการไม่สำเร็จ', 'ไม่สามารถเชื่อมต่อฐานข้อมูลได้', 'error');
        return false;
      } finally {
        setIsLoading(false);
      }
    },
    [adminSessionToken, callDirectSupabaseRpc, fetchDirectFromSupabase, showToast]
  );

  const manageChemical = useCallback(
    async (payload: {
      id?: string;
      code?: string;
      name?: string;
      divisor?: number;
      unit?: string;
      description?: string;
      active?: boolean;
      action?: 'add' | 'update' | 'toggle' | 'delete';
    }) => {
      setIsLoading(true);
      setLoadingMessage('กำลังอัปเดตข้อมูลสารเคมี...');
      try {
        const res = await fetch('/api/chemicals', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ ...payload, sessionToken: adminSessionToken }),
        });
        const contentType = res.headers.get('content-type') || '';
        if (res.status === 404 || res.status === 405 || !contentType.includes('application/json')) {
          throw new Error('Static host fallback');
        }
        const data = await res.json();
        if (!res.ok || !data.ok) {
          showToast('ดำเนินการไม่สำเร็จ', data?.error || 'ไม่สามารถอัปเดตสารเคมีได้', 'error');
          return false;
        }
        if (Array.isArray(data.chemicals)) setChemicals(data.chemicals);
        if (Array.isArray(data.audit_logs)) setAuditLogs(data.audit_logs);
        showToast('บันทึกสำเร็จ', 'ข้อมูลสารเคมีถูกบันทึกในฐานข้อมูลกลางแล้ว', 'success');
        return true;
      } catch (_err) {
        try {
          const sbAction =
            payload.action === 'delete' || payload.action === 'toggle'
              ? 'disable'
              : payload.action === 'update'
              ? 'update'
              : 'add';
          const rpc = await callDirectSupabaseRpc('admin_manage_chemical', {
            p_session_token: adminSessionToken,
            p_action: sbAction,
            ...(payload.id ? { p_id: payload.id } : {}),
            ...(payload.name ? { p_name: payload.name.trim() } : {}),
            ...(payload.divisor !== undefined ? { p_divisor: Number(payload.divisor) } : {}),
            ...(payload.unit ? { p_unit: payload.unit } : {}),
          });
          if (rpc.ok) {
            await fetchDirectFromSupabase();
            showToast('บันทึกสำเร็จ', 'ข้อมูลสารเคมีถูกบันทึกในฐานข้อมูลกลางแล้ว', 'success');
            return true;
          }
        } catch (_sbErr) {
          // Ignore and show error below
        }
        showToast('ดำเนินการไม่สำเร็จ', 'ไม่สามารถเชื่อมต่อฐานข้อมูลได้', 'error');
        return false;
      } finally {
        setIsLoading(false);
      }
    },
    [adminSessionToken, callDirectSupabaseRpc, fetchDirectFromSupabase, showToast]
  );

  return (
    <BoilerContext.Provider
      value={{
        settings,
        boilers,
        chemicals,
        history,
        auditLogs,
        supabaseOnline,
        supabaseUrl,
        isLoading,
        loadingMessage,
        toasts,
        adminUnlocked,
        adminSessionToken,
        hasUnreadHistory,
        markHistoryRead,
        showToast,
        dismissToast,
        refreshState,
        getLatestLevelForBoiler,
        submitCalculation,
        deleteHistoryRecord,
        loginAdmin,
        logoutAdmin,
        changeAdminPin,
        saveAppSettings,
        togglePermission,
        manageBoiler,
        manageChemical,
      }}
    >
      {children}
    </BoilerContext.Provider>
  );
};

export function useBoiler() {
  const ctx = useContext(BoilerContext);
  if (!ctx) {
    throw new Error('useBoiler must be used within a BoilerProvider');
  }
  return ctx;
}
