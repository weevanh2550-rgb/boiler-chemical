import React, { useState, useEffect } from 'react';
import { NavLink, useLocation, useNavigate } from 'react-router-dom';
import {
  CheckCircle2,
  AlertCircle,
  Info,
  FlaskConical,
  QrCode,
  X,
  Copy,
  Share2,
  Home,
  Calculator,
  History,
  Settings,
} from 'lucide-react';
import { useBoiler } from '../context/BoilerContext';
import appLogo from '../assets/images/boiler_press_chem_logo_1791513593157.jpg';

const FALLBACK_PUBLIC_URL = 'https://ais-dev-3h2c3yfgusnpkwaet556wl-520499311404.asia-east1.run.app/';

const resolveShareableAppUrl = (): string => {
  if (typeof window !== 'undefined' && window.location.origin) {
    const origin = window.location.origin;
    if (
      origin.includes('localhost') ||
      origin.includes('127.0.0.1') ||
      origin.includes('ais-pre-')
    ) {
      return FALLBACK_PUBLIC_URL;
    }
    return `${origin.replace(/\/+$/, '')}/`;
  }
  return FALLBACK_PUBLIC_URL;
};

const copyTextWithFallback = async (text: string): Promise<boolean> => {
  if (typeof navigator !== 'undefined' && navigator.clipboard?.writeText) {
    try {
      await navigator.clipboard.writeText(text);
      return true;
    } catch (_e) {
      // Fallback to textarea copy below
    }
  }
  try {
    const textarea = document.createElement('textarea');
    textarea.value = text;
    textarea.setAttribute('readonly', '');
    textarea.style.position = 'fixed';
    textarea.style.opacity = '0';
    textarea.style.pointerEvents = 'none';
    document.body.appendChild(textarea);
    textarea.focus();
    textarea.select();
    const ok = document.execCommand('copy');
    document.body.removeChild(textarea);
    return ok;
  } catch (_e) {
    return false;
  }
};

export const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const {
    settings,
    isLoading,
    loadingMessage,
    toasts,
    dismissToast,
    showToast,
    hasUnreadHistory,
    markHistoryRead,
  } = useBoiler();

  const [qrModalOpen, setQrModalOpen] = useState(false);
  const [liveWebUrl, setLiveWebUrl] = useState<string>(() => resolveShareableAppUrl());
  const location = useLocation();
  const navigate = useNavigate();
  const isHomePage = location.pathname === '/';

  // Automatically sync the real shareable app URL whenever opened or navigated
  useEffect(() => {
    setLiveWebUrl(resolveShareableAppUrl());
  }, [location.pathname, qrModalOpen]);

  const qrImageUrl = `https://api.qrserver.com/v1/create-qr-code/?size=320x320&margin=12&color=0369a1&data=${encodeURIComponent(
    liveWebUrl
  )}`;

  const handleCopyUrl = async () => {
    const appUrl = resolveShareableAppUrl();
    const copied = await copyTextWithFallback(appUrl);
    if (copied) {
      showToast('คัดลอกลิงก์แอปสำเร็จ', appUrl, 'success');
    } else {
      showToast('ลิงก์แอปสำหรับแชร์', appUrl, 'info');
    }
  };

  const handleShareUrl = async () => {
    const appUrl = resolveShareableAppUrl();
    if (typeof navigator !== 'undefined' && typeof navigator.share === 'function') {
      try {
        await navigator.share({
          url: appUrl,
        });
        return;
      } catch (err) {
        if (err instanceof Error && err.name === 'AbortError') {
          return;
        }
      }
    }
    const copied = await copyTextWithFallback(appUrl);
    if (copied) {
      showToast('คัดลอกลิงก์แชร์แอปสำเร็จ', 'นำลิงก์ไปวางส่งแชร์แอปได้ทันที', 'success');
    } else {
      showToast('ลิงก์แชร์แอป', appUrl, 'info');
    }
  };

  const handleNavClick = (
    e: React.MouseEvent,
    path: string,
    permKey?: keyof typeof settings.permissions,
    label?: string
  ) => {
    if (permKey && !settings.permissions[permKey]) {
      e.preventDefault();
      showToast(
        'ฟังก์ชันถูกปิดไว้',
        `ผู้ดูแลระบบปิดสิทธิ์${label || ''}ไว้ใน Permission Center`,
        'error'
      );
      return;
    }
    if (path === '/history') {
      markHistoryRead();
    }
    navigate(path);
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#f8f9fb] text-slate-800 select-none">
      {/* Top Bar with Logo & QR Button — ONLY visible on Home Page */}
      {isHomePage && (
        <header className="sticky top-0 z-30 bg-white border-b border-slate-200/80 shadow-2xs">
          <div className="max-w-md mx-auto px-4 h-16 flex items-center justify-between">
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-11 h-11 rounded-2xl overflow-hidden border border-slate-200 bg-slate-50 shadow-2xs shrink-0">
                <img
                  src={appLogo}
                  alt={settings.site_name}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="min-w-0">
                <div className="font-extrabold text-base tracking-tight text-slate-900 truncate">
                  {settings.site_name || 'BOILER CHEMICAL'}
                </div>
                <span className="block text-[11px] font-semibold text-slate-500 truncate">
                  Boiler Chemical Management
                </span>
              </div>
            </div>

            <button
              type="button"
              onClick={() => setQrModalOpen(true)}
              className="w-10 h-10 rounded-2xl border border-sky-100/90 bg-white hover:bg-sky-50 hover:border-sky-300 active:bg-sky-100 active:border-sky-400 active:scale-95 text-sky-600 flex items-center justify-center transition-all cursor-pointer shadow-2xs"
              aria-label="เปิด QR Code สำหรับเว็บแอป"
            >
              <QrCode className="w-5 h-5" />
            </button>
          </div>
        </header>
      )}

      {/* Main Content Stage */}
      <main className="flex-1 w-full max-w-md mx-auto px-4 pt-4 pb-24">
        {children}
      </main>

      {/* Bottom Navigation Bar (5 items: หน้าหลัก, การคำนวณ, ประวัติ, สารเคมี, การตั้งค่า) */}
      <nav
        aria-label="แถบเมนูด้านล่าง"
        className="fixed bottom-0 inset-x-0 z-40 bg-white/95 backdrop-blur-md border-t border-sky-100/90 shadow-[0_-4px_20px_rgba(14,165,233,0.08)]"
      >
        <div className="max-w-md mx-auto px-2 h-16 grid grid-cols-5 gap-1 items-center">
          <NavLink
            to="/"
            end
            className={({ isActive }) =>
              `flex flex-col items-center justify-center py-1.5 rounded-2xl border transition-all ${
                isActive
                  ? 'text-sky-600 bg-sky-50/90 border-sky-200/90 font-extrabold scale-[1.02]'
                  : 'text-slate-400 border-transparent hover:text-sky-600 hover:bg-sky-50/40 active:bg-sky-100/70 active:border-sky-200 active:text-sky-700 font-semibold'
              }`
            }
          >
            <Home className="w-5 h-5" />
            <span className="text-[11px] mt-0.5">หน้าหลัก</span>
          </NavLink>

          <NavLink
            to="/calculation"
            onClick={(e) => handleNavClick(e, '/calculation', 'allow_calculate', 'การคำนวณ')}
            className={({ isActive }) =>
              `flex flex-col items-center justify-center py-1.5 rounded-2xl border transition-all ${
                isActive
                  ? 'text-sky-600 bg-sky-50/90 border-sky-200/90 font-extrabold scale-[1.02]'
                  : 'text-slate-400 border-transparent hover:text-sky-600 hover:bg-sky-50/40 active:bg-sky-100/70 active:border-sky-200 active:text-sky-700 font-semibold'
              }`
            }
          >
            <Calculator className="w-5 h-5" />
            <span className="text-[11px] mt-0.5">การคำนวณ</span>
          </NavLink>

          <NavLink
            to="/history"
            onClick={(e) => handleNavClick(e, '/history', 'allow_history_view', 'การดูประวัติ')}
            className={({ isActive }) =>
              `relative flex flex-col items-center justify-center py-1.5 rounded-2xl border transition-all ${
                isActive
                  ? 'text-sky-600 bg-sky-50/90 border-sky-200/90 font-extrabold scale-[1.02]'
                  : 'text-slate-400 border-transparent hover:text-sky-600 hover:bg-sky-50/40 active:bg-sky-100/70 active:border-sky-200 active:text-sky-700 font-semibold'
              }`
            }
          >
            <div className="relative">
              <History className="w-5 h-5" />
              {hasUnreadHistory && location.pathname !== '/history' && (
                <span className="absolute -top-1 -right-1.5 w-2.5 h-2.5 rounded-full bg-rose-500 ring-2 ring-white" />
              )}
            </div>
            <span className="text-[11px] mt-0.5">ประวัติ</span>
          </NavLink>

          <NavLink
            to="/chemicals"
            onClick={(e) => handleNavClick(e, '/chemicals', 'allow_chemical_info', 'ข้อมูลสารเคมี')}
            className={({ isActive }) =>
              `flex flex-col items-center justify-center py-1.5 rounded-2xl border transition-all ${
                isActive
                  ? 'text-sky-600 bg-sky-50/90 border-sky-200/90 font-extrabold scale-[1.02]'
                  : 'text-slate-400 border-transparent hover:text-sky-600 hover:bg-sky-50/40 active:bg-sky-100/70 active:border-sky-200 active:text-sky-700 font-semibold'
              }`
            }
          >
            <FlaskConical className="w-5 h-5" />
            <span className="text-[11px] mt-0.5">สารเคมี</span>
          </NavLink>

          <NavLink
            to="/settings"
            className={({ isActive }) =>
              `flex flex-col items-center justify-center py-1.5 rounded-2xl border transition-all ${
                isActive
                  ? 'text-sky-600 bg-sky-50/90 border-sky-200/90 font-extrabold scale-[1.02]'
                  : 'text-slate-400 border-transparent hover:text-sky-600 hover:bg-sky-50/40 active:bg-sky-100/70 active:border-sky-200 active:text-sky-700 font-semibold'
              }`
            }
          >
            <Settings className="w-5 h-5" />
            <span className="text-[11px] mt-0.5">การตั้งค่า</span>
          </NavLink>
        </div>
      </nav>

      {/* Centered Loading Spinner Overlay */}
      {isLoading && (
        <div
          role="status"
          aria-live="polite"
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/20 backdrop-blur-[2px] p-4"
        >
          <div className="bg-white rounded-3xl border border-sky-100 shadow-xl px-6 py-5 flex flex-col items-center gap-3 max-w-[240px] w-full text-center">
            <div className="relative w-11 h-11 flex items-center justify-center">
              <div className="w-11 h-11 rounded-full border-4 border-sky-100 border-t-sky-600 animate-spin" />
              <FlaskConical className="w-4 h-4 text-sky-600 absolute" />
            </div>
            <p className="text-xs font-bold text-slate-700">{loadingMessage || 'กำลังโหลดข้อมูล...'}</p>
          </div>
        </div>
      )}

      {/* Clean Toast Alert */}
      <div className="fixed top-4 inset-x-0 z-50 flex flex-col items-center gap-2 pointer-events-none px-4">
        {toasts.map((t) => (
          <div
            key={t.id}
            role={t.type === 'error' ? 'alert' : 'status'}
            className={`pointer-events-auto flex items-center gap-2.5 px-4 py-3 rounded-2xl border shadow-lg backdrop-blur-md max-w-sm w-full transition-all ${
              t.type === 'success'
                ? 'bg-white/95 border-emerald-200 text-slate-800'
                : t.type === 'error'
                ? 'bg-white/95 border-rose-200 text-slate-800'
                : 'bg-white/95 border-sky-200 text-slate-800'
            }`}
          >
            <div className="shrink-0">
              {t.type === 'success' && <CheckCircle2 className="w-5 h-5 text-emerald-600" />}
              {t.type === 'error' && <AlertCircle className="w-5 h-5 text-rose-600" />}
              {t.type === 'info' && <Info className="w-5 h-5 text-sky-600" />}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-xs font-extrabold text-slate-900">{t.title}</p>
              {t.message && <p className="text-[11px] text-slate-500 truncate">{t.message}</p>}
            </div>
            <button
              type="button"
              onClick={() => dismissToast(t.id)}
              className="text-slate-400 hover:text-slate-600 p-1"
              aria-label="ปิด"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        ))}
      </div>

      {/* QR Code Modal (Auto-synced with Real Live URL) */}
      {qrModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-sky-950/50 backdrop-blur-xs">
          <div className="w-full max-w-xs bg-white rounded-3xl p-5 shadow-2xl border border-sky-100 text-center relative">
            <button
              type="button"
              onClick={() => setQrModalOpen(false)}
              aria-label="ปิด"
              className="absolute right-4 top-4 w-8 h-8 rounded-full bg-sky-50 text-sky-600 font-bold flex items-center justify-center cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
            <h3 className="text-base font-extrabold text-sky-800">QR Code</h3>
            <p className="text-[11px] text-slate-400 mt-0.5">สแกนเพื่อเปิดแอปบนเครื่องอื่น</p>

            <div className="mx-auto my-3 w-56 aspect-square rounded-2xl border border-sky-100 bg-white p-2 flex items-center justify-center shadow-2xs">
              <img
                src={qrImageUrl}
                alt="QR Code"
                referrerPolicy="no-referrer"
                className="w-full h-full object-contain"
              />
            </div>

            <div className="px-3 py-2 rounded-xl bg-sky-50 text-[10px] text-sky-700 break-all font-semibold mb-3">
              {liveWebUrl}
            </div>

            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={handleShareUrl}
                className="rounded-xl bg-sky-600 hover:bg-sky-700 active:bg-sky-800 active:scale-95 text-white py-2.5 text-xs font-extrabold flex items-center justify-center gap-1.5 transition-all cursor-pointer touch-manipulation"
              >
                <Share2 className="w-3.5 h-3.5" />
                <span>แชร์แอป</span>
              </button>
              <button
                type="button"
                onClick={handleCopyUrl}
                className="rounded-xl bg-emerald-100 hover:bg-emerald-200 text-emerald-700 py-2.5 text-xs font-extrabold flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Copy className="w-3.5 h-3.5" />
                <span>คัดลอก</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
