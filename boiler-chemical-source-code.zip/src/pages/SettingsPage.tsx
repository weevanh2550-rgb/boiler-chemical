import React, { useState, useRef, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  ChevronLeft,
  ChevronRight,
  Plus,
  X,
  Lock,
  ImagePlus,
  RotateCcw,
  Move,
  Check,
  ZoomIn,
  ZoomOut,
  Download,
} from 'lucide-react';
import { useBoiler } from '../context/BoilerContext';
import { PERMISSION_DEFINITIONS } from '../types/boiler';
import appLogo from '../assets/images/boiler_press_chem_logo_1791513593157.jpg';
import factoryBoilerBanner from '../assets/images/factory_boiler_department_banner_1791543564736.jpg';

const CROP_WIDTH = 960;
const CROP_HEIGHT = 360;

export const SettingsPage: React.FC = () => {
  const navigate = useNavigate();
  const {
    settings,
    boilers,
    chemicals,
    adminUnlocked,
    loginAdmin,
    logoutAdmin,
    changeAdminPin,
    saveAppSettings,
    togglePermission,
    manageBoiler,
    manageChemical,
    showToast,
  } = useBoiler();

  const [pinModalOpen, setPinModalOpen] = useState(false);
  const [adminPanelOpen, setAdminPanelOpen] = useState(false);
  const [pinInput, setPinInput] = useState('');
  const pinInputRef = useRef('');
  const pinBusyRef = useRef(false);
  const [pinErrorShake, setPinErrorShake] = useState(false);

  const updatePinValue = (val: string) => {
    pinInputRef.current = val;
    setPinInput(val);
  };

  // PIN Change Flow inside Keypad Modal (just like reference app)
  const [pinChangeMode, setPinChangeMode] = useState(false);
  const [pinChangeStage, setPinChangeStage] = useState<'CURRENT' | 'NEW' | 'CONFIRM'>('CURRENT');
  const [tempOldPin, setTempOldPin] = useState('');
  const [tempNewPin, setTempNewPin] = useState('');

  // Admin Edit States
  const [siteName, setSiteName] = useState(settings.site_name);
  const [appVersion, setAppVersion] = useState(settings.app_version);
  const [previewImageUrl, setPreviewImageUrl] = useState(settings.preview_image_url || '');
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Facebook-style Preview Reposition / Crop States
  const [isAdjustingPreview, setIsAdjustingPreview] = useState(false);
  const [cropSourceImg, setCropSourceImg] = useState<HTMLImageElement | null>(null);
  const [cropOffset, setCropOffset] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [cropZoom, setCropZoom] = useState<number>(1);
  const cropCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const dragStateRef = useRef<{
    active: boolean;
    startX: number;
    startY: number;
    origX: number;
    origY: number;
  }>({ active: false, startX: 0, startY: 0, origX: 0, origY: 0 });

  const [newBoilerName, setNewBoilerName] = useState('');
  const [editingBoilerId, setEditingBoilerId] = useState<string | null>(null);
  const [editingBoilerName, setEditingBoilerName] = useState('');

  const [newChemName, setNewChemName] = useState('');
  const [newChemDivisor, setNewChemDivisor] = useState('');
  const [editingChemId, setEditingChemId] = useState<string | null>(null);
  const [editingChemName, setEditingChemName] = useState('');
  const [editingChemDivisor, setEditingChemDivisor] = useState('');

  const clampCropOffset = useCallback(
    (img: HTMLImageElement, offset: { x: number; y: number }, zoom: number) => {
      const baseScale = Math.max(CROP_WIDTH / img.width, CROP_HEIGHT / img.height);
      const scale = baseScale * zoom;
      const drawW = img.width * scale;
      const drawH = img.height * scale;
      const maxOffsetX = Math.max(0, (drawW - CROP_WIDTH) / 2);
      const maxOffsetY = Math.max(0, (drawH - CROP_HEIGHT) / 2);
      return {
        x: Math.max(-maxOffsetX, Math.min(maxOffsetX, offset.x)),
        y: Math.max(-maxOffsetY, Math.min(maxOffsetY, offset.y)),
      };
    },
    []
  );

  const drawCropCanvas = useCallback(() => {
    const canvas = cropCanvasRef.current;
    const img = cropSourceImg;
    if (!canvas || !img) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const baseScale = Math.max(CROP_WIDTH / img.width, CROP_HEIGHT / img.height);
    const scale = baseScale * cropZoom;
    const drawW = img.width * scale;
    const drawH = img.height * scale;
    const clamped = clampCropOffset(img, cropOffset, cropZoom);
    const dx = (CROP_WIDTH - drawW) / 2 + clamped.x;
    const dy = (CROP_HEIGHT - drawH) / 2 + clamped.y;

    ctx.clearRect(0, 0, CROP_WIDTH, CROP_HEIGHT);
    ctx.drawImage(img, dx, dy, drawW, drawH);
  }, [cropSourceImg, cropOffset, cropZoom, clampCropOffset]);

  useEffect(() => {
    if (isAdjustingPreview && cropSourceImg) {
      drawCropCanvas();
    }
  }, [isAdjustingPreview, cropSourceImg, drawCropCanvas]);

  const triggerPinShake = () => {
    setPinErrorShake(true);
    setTimeout(() => {
      setPinErrorShake(false);
      updatePinValue('');
      pinBusyRef.current = false;
    }, 350);
  };

  const handleOpenAdmin = () => {
    if (adminUnlocked) {
      setSiteName(settings.site_name);
      setAppVersion(settings.app_version);
      setPreviewImageUrl(settings.preview_image_url || '');
      setIsAdjustingPreview(false);
      setCropSourceImg(null);
      setAdminPanelOpen(true);
    } else {
      setPinChangeMode(false);
      pinBusyRef.current = false;
      updatePinValue('');
      setPinModalOpen(true);
    }
  };

  const handleUploadPreviewFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      showToast('ไฟล์ไม่ถูกต้อง', 'กรุณาเลือกไฟล์รูปภาพจากคลังรูปเท่านั้น', 'error');
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      const img = new Image();
      img.onload = () => {
        setCropSourceImg(img);
        setCropZoom(1);
        setCropOffset({ x: 0, y: 0 });
        setIsAdjustingPreview(true);
      };
      img.src = String(reader.result || '');
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  const handleCropPointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!cropSourceImg) return;
    e.currentTarget.setPointerCapture(e.pointerId);
    dragStateRef.current = {
      active: true,
      startX: e.clientX,
      startY: e.clientY,
      origX: cropOffset.x,
      origY: cropOffset.y,
    };
  };

  const handleCropPointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!dragStateRef.current.active || !cropSourceImg) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const ratioX = rect.width > 0 ? CROP_WIDTH / rect.width : 1;
    const ratioY = rect.height > 0 ? CROP_HEIGHT / rect.height : 1;
    const dx = (e.clientX - dragStateRef.current.startX) * ratioX;
    const dy = (e.clientY - dragStateRef.current.startY) * ratioY;
    const nextClamped = clampCropOffset(
      cropSourceImg,
      {
        x: dragStateRef.current.origX + dx,
        y: dragStateRef.current.origY + dy,
      },
      cropZoom
    );
    setCropOffset(nextClamped);
  };

  const handleCropPointerUp = (e: React.PointerEvent<HTMLDivElement>) => {
    if (dragStateRef.current.active) {
      dragStateRef.current.active = false;
      try {
        e.currentTarget.releasePointerCapture(e.pointerId);
      } catch {
        // Ignore
      }
    }
  };

  const handleChangeCropZoom = (nextZoom: number) => {
    const clampedZoom = Math.max(1, Math.min(3, nextZoom));
    setCropZoom(clampedZoom);
    if (cropSourceImg) {
      setCropOffset((prev) => clampCropOffset(cropSourceImg, prev, clampedZoom));
    }
  };

  const handleConfirmCropPreview = async () => {
    const canvas = cropCanvasRef.current;
    if (!canvas || !cropSourceImg) return;
    drawCropCanvas();
    const compressedDataUrl = canvas.toDataURL('image/jpeg', 0.85);
    setPreviewImageUrl(compressedDataUrl);
    setIsAdjustingPreview(false);
    setCropSourceImg(null);
    await saveAppSettings({ preview_image_url: compressedDataUrl });
  };

  const handleCancelCropPreview = () => {
    setIsAdjustingPreview(false);
    setCropSourceImg(null);
    setCropOffset({ x: 0, y: 0 });
    setCropZoom(1);
  };

  const handleStartChangePinOnKeypad = () => {
    setPinChangeMode(true);
    setPinChangeStage('CURRENT');
    setTempOldPin('');
    setTempNewPin('');
    pinBusyRef.current = false;
    updatePinValue('');
    setPinModalOpen(true);
  };

  const handleKeypadPress = async (key: string) => {
    if (pinBusyRef.current) return;

    if (key === 'CLEAR') {
      updatePinValue('');
      return;
    }
    if (key === 'BACK') {
      updatePinValue(pinInputRef.current.slice(0, -1));
      return;
    }
    if (/^\d$/.test(key) && pinInputRef.current.length < 4) {
      const next = pinInputRef.current + key;
      updatePinValue(next);

      if (next.length === 4) {
        pinBusyRef.current = true;
        if (pinChangeMode) {
          if (pinChangeStage === 'CURRENT') {
            const verify = await loginAdmin(next);
            if (!verify.ok) {
              triggerPinShake();
              return;
            }
            setTempOldPin(next);
            setPinChangeStage('NEW');
            updatePinValue('');
            pinBusyRef.current = false;
            return;
          }
          if (pinChangeStage === 'NEW') {
            setTempNewPin(next);
            setPinChangeStage('CONFIRM');
            updatePinValue('');
            pinBusyRef.current = false;
            return;
          }
          if (pinChangeStage === 'CONFIRM') {
            if (next !== tempNewPin) {
              showToast('รหัสไม่ตรงกัน', 'กรุณาตั้งรหัสใหม่ 4 หลักอีกครั้ง', 'error');
              setPinChangeStage('NEW');
              triggerPinShake();
              return;
            }
            const res = await changeAdminPin(tempOldPin, next);
            if (res.ok) {
              setPinChangeMode(false);
              setPinModalOpen(false);
              updatePinValue('');
              pinBusyRef.current = false;
            } else {
              triggerPinShake();
            }
            return;
          }
        } else {
          const res = await loginAdmin(next);
          if (res.ok) {
            setPinModalOpen(false);
            updatePinValue('');
            pinBusyRef.current = false;
            setSiteName(settings.site_name);
            setAppVersion(settings.app_version);
            setPreviewImageUrl(settings.preview_image_url || '');
            setAdminPanelOpen(true);
          } else {
            triggerPinShake();
          }
        }
      }
    }
  };

  const handleAddBoiler = async () => {
    if (!newBoilerName.trim()) return;
    const ok = await manageBoiler({ action: 'add', name: newBoilerName.trim() });
    if (ok) setNewBoilerName('');
  };

  const handleSaveBoilerRename = async (id: string) => {
    if (!editingBoilerName.trim()) return;
    const ok = await manageBoiler({ id, name: editingBoilerName.trim(), action: 'rename' });
    if (ok) {
      setEditingBoilerId(null);
      setEditingBoilerName('');
    }
  };

  const handleAddChemical = async () => {
    const div = parseFloat(newChemDivisor);
    if (!newChemName.trim() || !Number.isFinite(div) || div <= 0) {
      showToast('ข้อมูลไม่ถูกต้อง', 'กรุณาระบุชื่อสารเคมีและตัวหารที่ถูกต้อง', 'error');
      return;
    }
    const ok = await manageChemical({
      action: 'add',
      name: newChemName.trim(),
      divisor: div,
      unit: 'L',
    });
    if (ok) {
      setNewChemName('');
      setNewChemDivisor('');
    }
  };

  const handleSaveChemUpdate = async (id: string) => {
    const div = parseFloat(editingChemDivisor);
    if (!editingChemName.trim() || !Number.isFinite(div) || div <= 0) {
      showToast('ข้อมูลไม่ถูกต้อง', 'กรุณาระบุชื่อและตัวหารให้ถูกต้อง', 'error');
      return;
    }
    const ok = await manageChemical({
      id,
      name: editingChemName.trim(),
      divisor: div,
      action: 'update',
    });
    if (ok) {
      setEditingChemId(null);
      setEditingChemName('');
      setEditingChemDivisor('');
    }
  };

  const pinHintText = pinChangeMode
    ? pinChangeStage === 'CURRENT'
      ? 'ใส่รหัส Admin เดิม 4 หลัก'
      : pinChangeStage === 'NEW'
      ? 'ตั้งรหัสใหม่ 4 หลัก'
      : 'ยืนยันรหัสใหม่ 4 หลัก'
    : 'กรุณาใส่รหัส Admin 4 หลัก';

  return (
    <div className="space-y-4">
      {/* Subpage Header */}
      <div className="flex items-center gap-3 pt-1">
        <button
          type="button"
          onClick={() => navigate('/')}
          aria-label="กลับหน้าหลัก"
          className="w-10 h-10 rounded-2xl bg-white border border-sky-100/90 text-sky-700 hover:bg-sky-50/70 hover:border-sky-300 active:bg-sky-100 active:border-sky-400 active:scale-95 flex items-center justify-center text-xl font-bold shadow-2xs transition-all cursor-pointer"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>
        <div>
          <span className="block text-[9px] font-black tracking-[2px] text-sky-600 uppercase">
            SETTINGS
          </span>
          <h2 className="text-lg font-extrabold text-slate-900 -mt-0.5">การตั้งค่า</h2>
        </div>
      </div>

      {/* Admin Profile Row Card */}
      <button
        type="button"
        onClick={handleOpenAdmin}
        className="w-full rounded-3xl bg-white border border-sky-100/90 hover:border-sky-300 hover:bg-sky-50/40 active:border-sky-400 active:bg-sky-100/60 active:ring-2 active:ring-sky-200/80 active:scale-[0.99] p-4 shadow-2xs flex items-center gap-3.5 text-left transition-all duration-150 cursor-pointer"
      >
        <img
          src={appLogo}
          alt="ผู้ดูแลระบบ"
          referrerPolicy="no-referrer"
          className="w-12 h-12 rounded-2xl object-cover border border-sky-100/90 shrink-0"
        />
        <div className="min-w-0 flex-1">
          <div className="font-extrabold text-sm text-slate-900">ผู้ดูแลระบบ</div>
          <div className="text-[11px] text-slate-400 truncate mt-0.5">
            กดเพื่อเข้าสู่ฟังก์ชันผู้ดูแลระบบ • ต้องใส่รหัส PIN
          </div>
        </div>
        <ChevronRight className="w-5 h-5 text-sky-500 shrink-0" />
      </button>

      {/* General & App Info Section */}
      <div className="space-y-2 pt-1">
        <div className="text-[11px] font-bold text-slate-400 px-1">ทั่วไป • ข้อมูลแอป</div>

        <div className="rounded-3xl bg-white border border-sky-100/90 hover:border-sky-200 active:border-sky-300 active:bg-sky-50/30 p-4 shadow-2xs flex items-center gap-3.5 transition-all">
          <img
            src={appLogo}
            alt="โลโก้ระบบสารเคมี"
            referrerPolicy="no-referrer"
            className="w-14 h-14 rounded-2xl object-cover border border-sky-100/90 shrink-0"
          />
          <div>
            <strong className="text-sm font-extrabold text-slate-900 block">
              {settings.site_name || 'Boiler Chemical'}
            </strong>
            <p className="text-xs text-slate-500 mt-0.5">
              ระบบจัดการและคำนวณสารเคมี
            </p>
            <span className="inline-block mt-1 text-[11px] font-bold text-sky-600 bg-sky-50 px-2.5 py-0.5 rounded-lg border border-sky-100">
              เวอร์ชัน <b>{settings.app_version || '3.0.0'}</b>
            </span>
          </div>
        </div>

        <div className="rounded-3xl bg-white border border-sky-100/90 hover:border-sky-200 active:border-sky-300 active:bg-sky-50/30 p-4 shadow-2xs divide-y divide-sky-50 text-xs transition-all">
          <div className="flex items-center justify-between py-2.5 first:pt-0">
            <span className="text-slate-500">ผู้พัฒนา</span>
            <b className="text-slate-800">{settings.developer_name}</b>
          </div>
          <div className="flex items-center justify-between py-2.5">
            <span className="text-slate-500">ประเภทระบบ</span>
            <b className="text-slate-800">Boiler Chemical Management</b>
          </div>
          <div className="flex items-center justify-between py-2.5 last:pb-0">
            <span className="text-slate-500">ลิขสิทธิ์</span>
            <b className="text-slate-800">© {settings.copyright_name}</b>
          </div>
        </div>
      </div>

      {/* Direct Download Section for GitHub & Vercel (Visible directly without PIN) */}
      <div className="space-y-2 pt-1">
        <div className="text-[11px] font-bold text-slate-400 px-1">
          ดาวน์โหลดไฟล์โค้ด • สำหรับนำขึ้น GitHub / Vercel
        </div>
        <div className="rounded-3xl bg-white border border-sky-100/90 p-4 shadow-2xs space-y-2.5">
          <div>
            <div className="text-xs font-extrabold text-slate-900">
              ดาวน์โหลดไฟล์โค้ดทั้งหมดออกจากระบบ
            </div>
            <p className="text-[11px] text-slate-500 mt-0.5 leading-relaxed">
              เลือกโหลดไฟล์ด้านล่างเพื่อนำไปอัปโหลดเข้า <b>GitHub (Add file &rarr; Upload files)</b> แล้วเชื่อมต่อกับ <b>Vercel</b> ได้ทันที
            </p>
          </div>

          <div className="grid grid-cols-1 gap-2 pt-0.5">
            <a
              href="/api/download/index.html"
              download="index.html"
              target="_blank"
              rel="noopener noreferrer"
              className="w-full py-2.5 px-3.5 rounded-2xl bg-emerald-600 hover:bg-emerald-700 active:scale-[0.99] text-white text-xs font-extrabold flex items-center justify-center gap-2 shadow-xs transition-all cursor-pointer"
            >
              <Download className="w-4 h-4 shrink-0" />
              <span>1. โหลดไฟล์เดียวจบ index.html (อัปเข้า GitHub ง่ายที่สุด)</span>
            </a>

            <a
              href="/api/download/boiler-chemical-ready-web.zip"
              download="boiler-chemical-ready-web.zip"
              target="_blank"
              rel="noopener noreferrer"
              className="w-full py-2.5 px-3.5 rounded-2xl bg-sky-600 hover:bg-sky-700 active:scale-[0.99] text-white text-xs font-extrabold flex items-center justify-center gap-2 shadow-xs transition-all cursor-pointer"
            >
              <Download className="w-4 h-4 shrink-0" />
              <span>2. โหลดไฟล์เว็บพร้อมใช้งาน (.ZIP)</span>
            </a>

            <a
              href="/api/download/boiler-chemical-source-code.zip"
              download="boiler-chemical-source-code.zip"
              target="_blank"
              rel="noopener noreferrer"
              className="w-full py-2.5 px-3.5 rounded-2xl bg-slate-100 hover:bg-slate-200 active:scale-[0.99] text-slate-700 text-xs font-extrabold flex items-center justify-center gap-2 transition-all cursor-pointer"
            >
              <Download className="w-4 h-4 shrink-0" />
              <span>3. โหลดซอร์สโค้ดทั้งหมด (Source Code .ZIP)</span>
            </a>
          </div>
        </div>
      </div>

      {/* Full Admin Settings Panel Modal */}
      {adminPanelOpen && adminUnlocked && (
        <div className="fixed inset-0 z-40 flex items-center justify-center bg-sky-950/50 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl border border-sky-100 shadow-2xl max-w-md w-full p-5 max-h-[88vh] overflow-y-auto space-y-5 relative">
            <div className="flex items-center justify-between border-b border-sky-100 pb-3">
              <div>
                <h3 className="text-base font-extrabold text-sky-800">ตั้งค่าระบบ (Admin)</h3>
                <p className="text-[11px] text-slate-400">
                  บันทึกข้อมูลลงฐานข้อมูลกลางและอัปเดตทันทีทุกเครื่อง
                </p>
              </div>
              <button
                type="button"
                onClick={() => {
                  setAdminPanelOpen(false);
                  logoutAdmin();
                }}
                className="w-8 h-8 rounded-full bg-slate-100 hover:bg-rose-100 hover:text-rose-600 flex items-center justify-center text-slate-500"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* 1. ชื่อเว็บไซต์ & เวอร์ชัน */}
            <div className="space-y-2">
              <label className="block text-xs font-extrabold text-slate-800">
                ข้อมูลระบบและเลขเวอร์ชัน
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={siteName}
                  onChange={(e) => setSiteName(e.target.value)}
                  placeholder="ชื่อระบบ"
                  className="flex-1 rounded-xl border border-sky-200 px-3 py-2 text-xs font-bold"
                />
                <input
                  type="text"
                  value={appVersion}
                  onChange={(e) => setAppVersion(e.target.value)}
                  placeholder="เวอร์ชัน"
                  className="w-24 rounded-xl border border-sky-200 px-3 py-2 text-xs font-bold"
                />
                <button
                  type="button"
                  onClick={() => saveAppSettings({ site_name: siteName, app_version: appVersion })}
                  className="px-3 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-xs font-bold cursor-pointer"
                >
                  บันทึก
                </button>
              </div>
            </div>

            {/* 1.5 เปลี่ยนภาพพรีวิวหน้าหลัก (Preview Banner) */}
            <div className="space-y-2.5">
              <div className="flex items-center justify-between">
                <label className="block text-xs font-extrabold text-slate-800">
                  ภาพพรีวิวหน้าหลัก (Preview Banner)
                </label>
                {Boolean(settings.preview_image_url || previewImageUrl) && !isAdjustingPreview && (
                  <button
                    type="button"
                    onClick={async () => {
                      setPreviewImageUrl('');
                      setIsAdjustingPreview(false);
                      setCropSourceImg(null);
                      await saveAppSettings({ preview_image_url: '' });
                    }}
                    className="inline-flex items-center gap-1 text-[10px] font-bold text-slate-500 hover:text-rose-600 bg-slate-100 hover:bg-rose-50 px-2 py-1 rounded-lg cursor-pointer"
                  >
                    <RotateCcw className="w-3 h-3" />
                    <span>คืนค่ารูปโรงงานเริ่มต้น</span>
                  </button>
                )}
              </div>

              {isAdjustingPreview && cropSourceImg ? (
                <div className="space-y-2.5 rounded-2xl border border-sky-200 bg-sky-50/40 p-2.5">
                  <div
                    onPointerDown={handleCropPointerDown}
                    onPointerMove={handleCropPointerMove}
                    onPointerUp={handleCropPointerUp}
                    onPointerCancel={handleCropPointerUp}
                    className="w-full h-36 rounded-2xl overflow-hidden border-2 border-sky-500 bg-slate-900 relative shadow-sm select-none touch-none cursor-grab active:cursor-grabbing"
                  >
                    <canvas
                      ref={cropCanvasRef}
                      width={CROP_WIDTH}
                      height={CROP_HEIGHT}
                      className="w-full h-full object-cover block pointer-events-none"
                    />
                    <div className="absolute inset-0 bg-gradient-to-r from-slate-950/75 via-slate-900/45 to-slate-900/20 flex flex-col justify-center px-5 pointer-events-none">
                      <span className="block text-sm font-extrabold tracking-wide text-sky-400 leading-tight drop-shadow-sm">
                        Welcome
                      </span>
                      <span className="block text-2xl font-extrabold text-white leading-tight mt-0.5 drop-shadow-md">
                        ยินดีต้อนรับ
                      </span>
                    </div>
                    <div className="absolute top-2.5 right-2.5 bg-slate-950/80 text-white text-[10px] font-bold px-2.5 py-1 rounded-full flex items-center gap-1.5 backdrop-blur-xs border border-white/15 pointer-events-none shadow-sm">
                      <Move className="w-3 h-3 text-sky-400" />
                      <span>กดค้างแล้วลากเพื่อเลื่อนหามุมที่ต้องการ</span>
                    </div>
                  </div>

                  {/* Zoom Slider for Fine-Tuning Angle & Framing */}
                  <div className="flex items-center gap-2 px-1">
                    <button
                      type="button"
                      onClick={() => handleChangeCropZoom(cropZoom - 0.15)}
                      aria-label="ซูมออก"
                      className="w-7 h-7 rounded-lg bg-white border border-sky-200 text-slate-600 hover:text-sky-700 hover:bg-sky-50 flex items-center justify-center shrink-0 cursor-pointer"
                    >
                      <ZoomOut className="w-3.5 h-3.5" />
                    </button>
                    <input
                      type="range"
                      min="1"
                      max="3"
                      step="0.02"
                      value={cropZoom}
                      onChange={(e) => handleChangeCropZoom(parseFloat(e.target.value))}
                      aria-label="ซูมปรับขนาดภาพพรีวิว"
                      className="flex-1 accent-sky-600 h-1.5 bg-sky-200 rounded-lg cursor-pointer"
                    />
                    <button
                      type="button"
                      onClick={() => handleChangeCropZoom(cropZoom + 0.15)}
                      aria-label="ซูมเข้า"
                      className="w-7 h-7 rounded-lg bg-white border border-sky-200 text-slate-600 hover:text-sky-700 hover:bg-sky-50 flex items-center justify-center shrink-0 cursor-pointer"
                    >
                      <ZoomIn className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  {/* Cancel & Confirm Buttons (Facebook Profile Reposition Style) */}
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={handleCancelCropPreview}
                      className="flex-1 py-2 px-3 rounded-xl bg-white hover:bg-slate-100 border border-slate-200 text-slate-600 text-xs font-extrabold flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <X className="w-3.5 h-3.5" />
                      <span>ยกเลิก</span>
                    </button>
                    <button
                      type="button"
                      onClick={handleConfirmCropPreview}
                      className="flex-1 py-2 px-3 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-xs font-extrabold flex items-center justify-center gap-1.5 shadow-xs cursor-pointer"
                    >
                      <Check className="w-4 h-4" />
                      <span>ยืนยัน</span>
                    </button>
                  </div>
                </div>
              ) : (
                <>
                  <div className="w-full h-36 rounded-2xl overflow-hidden border border-sky-200 bg-slate-900 relative shadow-2xs">
                    <img
                      src={previewImageUrl.trim() ? previewImageUrl.trim() : factoryBoilerBanner}
                      alt="ตัวอย่างภาพพรีวิว"
                      referrerPolicy="no-referrer"
                      onError={(e) => {
                        const target = e.currentTarget;
                        if (target.src !== factoryBoilerBanner) {
                          target.src = factoryBoilerBanner;
                        }
                      }}
                      className="w-full h-full object-cover object-center"
                    />
                    <div className="absolute inset-0 bg-gradient-to-r from-slate-950/75 via-slate-900/45 to-slate-900/20 flex flex-col justify-center px-5">
                      <span className="block text-sm font-extrabold tracking-wide text-sky-400 leading-tight drop-shadow-sm">
                        Welcome
                      </span>
                      <span className="block text-2xl font-extrabold text-white leading-tight mt-0.5 drop-shadow-md">
                        ยินดีต้อนรับ
                      </span>
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => fileInputRef.current?.click()}
                      className="flex-1 py-2.5 px-3 rounded-xl bg-sky-50 hover:bg-sky-100 border border-sky-200 text-sky-700 text-xs font-extrabold flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <ImagePlus className="w-4 h-4" />
                      <span>เลือกรูปภาพจากคลังรูป</span>
                    </button>
                  </div>
                </>
              )}

              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleUploadPreviewFile}
                className="hidden"
              />
            </div>

            {/* 2. Permission Center */}
            <div className="space-y-2">
              <label className="block text-xs font-extrabold text-slate-800">
                Permission Center (เปิด-ปิดสิทธิ์การใช้งาน)
              </label>
              <div className="space-y-1.5">
                {PERMISSION_DEFINITIONS.map((perm) => {
                  const isOn = settings.permissions[perm.key] !== false;
                  return (
                    <div
                      key={perm.key}
                      className="flex items-center justify-between p-2.5 rounded-2xl bg-sky-50/50 border border-sky-100"
                    >
                      <div>
                        <div className="text-xs font-bold text-slate-800">{perm.label}</div>
                        <div className="text-[10px] text-slate-400">{perm.description}</div>
                      </div>
                      <button
                        type="button"
                        onClick={() => togglePermission(perm.key)}
                        className={`w-11 h-6 rounded-full p-0.5 transition-colors cursor-pointer ${
                          isOn ? 'bg-sky-600' : 'bg-slate-300'
                        }`}
                      >
                        <span
                          className={`block w-5 h-5 rounded-full bg-white transition-transform ${
                            isOn ? 'translate-x-5' : 'translate-x-0'
                          }`}
                        />
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* 3. จัดการ Boiler */}
            <div className="space-y-2">
              <label className="block text-xs font-extrabold text-slate-800">
                จัดการรายการ Boiler
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={newBoilerName}
                  onChange={(e) => setNewBoilerName(e.target.value)}
                  placeholder="ชื่อ Boiler ใหม่..."
                  className="flex-1 rounded-xl border border-sky-200 px-3 py-2 text-xs font-bold"
                />
                <button
                  type="button"
                  onClick={handleAddBoiler}
                  className="px-3 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-xs font-bold flex items-center gap-1 cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>เพิ่ม</span>
                </button>
              </div>
              <div className="space-y-1.5">
                {boilers.map((b) => {
                  const isEditing = editingBoilerId === b.id;
                  return (
                    <div
                      key={b.id}
                      className="flex items-center justify-between p-2 rounded-xl border border-sky-200 bg-white text-xs shadow-2xs"
                    >
                      {isEditing ? (
                        <div className="flex items-center gap-1.5 flex-1">
                          <input
                            type="text"
                            value={editingBoilerName}
                            onChange={(e) => setEditingBoilerName(e.target.value)}
                            className="flex-1 rounded-lg border border-sky-300 px-2 py-1 text-xs font-bold"
                          />
                          <button
                            type="button"
                            onClick={() => handleSaveBoilerRename(b.id)}
                            className="px-2 py-1 rounded-lg bg-sky-600 text-white text-[10px] font-bold"
                          >
                            บันทึก
                          </button>
                          <button
                            type="button"
                            onClick={() => setEditingBoilerId(null)}
                            className="px-2 py-1 rounded-lg bg-slate-100 text-slate-600 text-[10px] font-bold"
                          >
                            ยกเลิก
                          </button>
                        </div>
                      ) : (
                        <>
                          <span className="font-bold text-slate-700">{b.name}</span>
                          <div className="flex gap-1">
                            <button
                              type="button"
                              onClick={() => {
                                setEditingBoilerId(b.id);
                                setEditingBoilerName(b.name);
                              }}
                              className="text-[10px] font-bold text-sky-600 bg-sky-50 hover:bg-sky-100 px-2 py-1 rounded-lg"
                            >
                              แก้
                            </button>
                            <button
                              type="button"
                              onClick={() => manageBoiler({ id: b.id, action: 'delete' })}
                              className="text-[10px] font-bold text-rose-500 bg-rose-50 hover:bg-rose-100 px-2 py-1 rounded-lg"
                            >
                              ปิด
                            </button>
                          </div>
                        </>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* 4. จัดการสารเคมี */}
            <div className="space-y-2">
              <label className="block text-xs font-extrabold text-slate-800">
                จัดการสารเคมีและตัวหาร
              </label>
              <div className="grid grid-cols-12 gap-2">
                <input
                  type="text"
                  value={newChemName}
                  onChange={(e) => setNewChemName(e.target.value)}
                  placeholder="ชื่อสารเคมี"
                  className="col-span-6 rounded-xl border border-sky-200 px-3 py-2 text-xs font-bold"
                />
                <input
                  type="number"
                  step="any"
                  value={newChemDivisor}
                  onChange={(e) => setNewChemDivisor(e.target.value)}
                  placeholder="ตัวหาร"
                  className="col-span-3 rounded-xl border border-sky-200 px-2.5 py-2 text-xs font-bold"
                />
                <button
                  type="button"
                  onClick={handleAddChemical}
                  className="col-span-3 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-xs font-bold cursor-pointer"
                >
                  + เพิ่ม
                </button>
              </div>
              <div className="space-y-1.5">
                {chemicals.map((c) => {
                  const isEditing = editingChemId === c.id;
                  return (
                    <div
                      key={c.id}
                      className="flex items-center justify-between p-2 rounded-xl border border-sky-200 bg-white text-xs shadow-2xs"
                    >
                      {isEditing ? (
                        <div className="flex items-center gap-1.5 flex-1">
                          <input
                            type="text"
                            value={editingChemName}
                            onChange={(e) => setEditingChemName(e.target.value)}
                            className="flex-1 rounded-lg border border-sky-300 px-2 py-1 text-xs font-bold"
                          />
                          <input
                            type="number"
                            step="any"
                            value={editingChemDivisor}
                            onChange={(e) => setEditingChemDivisor(e.target.value)}
                            className="w-16 rounded-lg border border-sky-300 px-2 py-1 text-xs font-bold"
                          />
                          <button
                            type="button"
                            onClick={() => handleSaveChemUpdate(c.id)}
                            className="px-2 py-1 rounded-lg bg-sky-600 text-white text-[10px] font-bold"
                          >
                            บันทึก
                          </button>
                          <button
                            type="button"
                            onClick={() => setEditingChemId(null)}
                            className="px-2 py-1 rounded-lg bg-slate-100 text-slate-600 text-[10px] font-bold"
                          >
                            ยกเลิก
                          </button>
                        </div>
                      ) : (
                        <>
                          <div>
                            <span className="font-bold text-slate-700">{c.name}</span>
                            <span className="ml-1.5 text-[10px] font-bold text-sky-600 bg-sky-50 px-1.5 py-0.5 rounded-md">
                              ÷ {c.divisor}
                            </span>
                          </div>
                          <div className="flex gap-1">
                            <button
                              type="button"
                              onClick={() => {
                                setEditingChemId(c.id);
                                setEditingChemName(c.name);
                                setEditingChemDivisor(String(c.divisor));
                              }}
                              className="text-[10px] font-bold text-sky-600 bg-sky-50 hover:bg-sky-100 px-2 py-1 rounded-lg"
                            >
                              แก้
                            </button>
                            <button
                              type="button"
                              onClick={() => manageChemical({ id: c.id, action: 'delete' })}
                              className="text-[10px] font-bold text-rose-500 bg-rose-50 hover:bg-rose-100 px-2 py-1 rounded-lg"
                            >
                              ปิด
                            </button>
                          </div>
                        </>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* 5. เปลี่ยนรหัส Admin PIN */}
            <div className="pt-2 border-t border-sky-100 flex items-center justify-between">
              <div>
                <div className="text-xs font-extrabold text-slate-800">รหัสผ่านผู้ดูแลระบบ</div>
                <div className="text-[10px] text-slate-400">เปลี่ยนรหัส Admin PIN 4 หลัก</div>
              </div>
              <button
                type="button"
                onClick={handleStartChangePinOnKeypad}
                className="px-3.5 py-2 rounded-xl bg-sky-50 hover:bg-sky-100 text-sky-700 text-xs font-extrabold cursor-pointer"
              >
                เปลี่ยนรหัส PIN
              </button>
            </div>

            {/* 6. ดาวน์โหลดไฟล์สำหรับนำขึ้นเว็บภายนอก (GitHub / Vercel / Netlify) */}
            <div className="pt-3 border-t border-sky-100 space-y-2">
              <div>
                <div className="text-xs font-extrabold text-slate-800">
                  ไฟล์สำหรับนำขึ้น GitHub / Vercel (ออนไลน์ 24 ชม. ฟรี)
                </div>
                <div className="text-[10px] text-slate-500">
                  แนะนำปุ่มแรก: ได้ไฟล์ <b>index.html</b> ไฟล์เดียวจบ (ไม่ต้องแตกไฟล์ ZIP) อัปโหลดใส่ GitHub เพื่อเข้า Vercel ได้ทันที
                </div>
              </div>
              <div className="grid grid-cols-1 gap-2">
                <a
                  href="/api/download/index.html"
                  download="index.html"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full py-2.5 px-3.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:scale-[0.99] text-white text-xs font-extrabold flex items-center justify-center gap-2 shadow-xs transition-all"
                >
                  <Download className="w-4 h-4 shrink-0" />
                  <span>ดาวน์โหลด index.html ไฟล์เดียวจบ (อัปขึ้น GitHub / Vercel)</span>
                </a>
                <a
                  href="/api/download/boiler-chemical-ready-web.zip"
                  download="boiler-chemical-ready-web.zip"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full py-2 px-3.5 rounded-xl bg-sky-600 hover:bg-sky-700 active:scale-[0.99] text-white text-[11px] font-extrabold flex items-center justify-center gap-2 shadow-xs transition-all"
                >
                  <Download className="w-3.5 h-3.5 shrink-0" />
                  <span>ดาวน์โหลดไฟล์เว็บ ZIP (สำหรับลากวาง Netlify Drop)</span>
                </a>
                <a
                  href="/api/download/boiler-chemical-source-code.zip"
                  download="boiler-chemical-source-code.zip"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full py-2 px-3.5 rounded-xl bg-slate-100 hover:bg-slate-200 active:scale-[0.99] text-slate-700 text-[11px] font-bold flex items-center justify-center gap-2 transition-all"
                >
                  <Download className="w-3.5 h-3.5 shrink-0" />
                  <span>ดาวน์โหลดซอร์สโค้ดเต็ม ZIP (Source Code ทั้งหมด)</span>
                </a>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 4-Digit Admin PIN Lock Modal (No default PIN hints shown) */}
      {pinModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-sky-950/50 backdrop-blur-xs p-4">
          <div className="bg-white rounded-3xl p-5 max-w-xs w-full shadow-2xl border border-sky-100 relative">
            <button
              type="button"
              onClick={() => {
                pinBusyRef.current = false;
                updatePinValue('');
                setPinModalOpen(false);
                setPinChangeMode(false);
              }}
              aria-label="ออกจากหน้ารหัส"
              className="absolute top-3.5 right-3.5 w-8 h-8 rounded-full bg-slate-100 text-slate-500 hover:bg-rose-100 hover:text-rose-600 flex items-center justify-center"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="text-center mb-4">
              <div className="w-11 h-11 mx-auto mb-2 rounded-full bg-sky-50 text-sky-600 flex items-center justify-center">
                <Lock className="w-5 h-5" />
              </div>
              <h3 className="text-base font-extrabold text-sky-700">
                {pinChangeMode ? 'เปลี่ยนรหัสผู้ดูแลระบบ' : 'เข้าสู่การตั้งค่าระบบ'}
              </h3>
              <p className="text-xs text-slate-500 font-semibold mt-0.5">สำหรับผู้ดูแลระบบ</p>
            </div>

            {/* PIN Dots */}
            <div
              className={`flex justify-center items-center gap-3 my-3 transition-transform ${
                pinErrorShake ? 'translate-x-1.5 text-rose-500' : ''
              }`}
            >
              {[0, 1, 2, 3].map((i) => (
                <span
                  key={i}
                  className={`w-3.5 h-3.5 rounded-full transition-all ${
                    pinErrorShake
                      ? 'bg-rose-500 scale-110'
                      : pinInput.length > i
                      ? 'bg-sky-600 scale-110'
                      : 'bg-slate-200'
                  }`}
                />
              ))}
            </div>

            <p className="text-[11px] text-slate-400 font-semibold text-center mb-3">
              {pinHintText}
            </p>

            {/* Numeric Keypad */}
            <div className="grid grid-cols-3 gap-2.5 max-w-[240px] mx-auto select-none touch-manipulation">
              {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((digit) => (
                <button
                  key={digit}
                  type="button"
                  onClick={() => handleKeypadPress(digit)}
                  className="h-11 rounded-2xl bg-sky-50/70 hover:bg-sky-100 active:bg-sky-200 active:scale-95 border border-sky-100 text-sm font-extrabold text-slate-800 cursor-pointer touch-manipulation select-none transition-transform duration-75"
                >
                  {digit}
                </button>
              ))}
              <button
                type="button"
                onClick={() => handleKeypadPress('CLEAR')}
                className="h-11 rounded-2xl bg-slate-100 hover:bg-slate-200 active:bg-slate-300 active:scale-95 text-[11px] font-bold text-slate-600 cursor-pointer touch-manipulation select-none transition-transform duration-75"
              >
                ล้าง
              </button>
              <button
                type="button"
                onClick={() => handleKeypadPress('0')}
                className="h-11 rounded-2xl bg-sky-50/70 hover:bg-sky-100 active:bg-sky-200 active:scale-95 border border-sky-100 text-sm font-extrabold text-slate-800 cursor-pointer touch-manipulation select-none transition-transform duration-75"
              >
                0
              </button>
              <button
                type="button"
                onClick={() => handleKeypadPress('BACK')}
                className="h-11 rounded-2xl bg-rose-50 hover:bg-rose-100 active:bg-rose-200 active:scale-95 text-[11px] font-bold text-rose-600 cursor-pointer touch-manipulation select-none transition-transform duration-75"
              >
                ลบ
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
