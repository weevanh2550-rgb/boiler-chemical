import React from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Calculator,
  History,
  FlaskConical,
  Settings,
  ChevronRight,
} from 'lucide-react';
import { useBoiler } from '../context/BoilerContext';
import factoryBoilerBanner from '../assets/images/factory_boiler_department_banner_1791543564736.jpg';

export const HomeDashboard: React.FC = () => {
  const navigate = useNavigate();
  const { settings, hasUnreadHistory, markHistoryRead, showToast } = useBoiler();

  const handleOpenMenu = (
    path: string,
    permKey?: keyof typeof settings.permissions,
    label?: string
  ) => {
    if (permKey && !settings.permissions[permKey]) {
      showToast(
        'ฟังก์ชันถูกปิดไว้',
        `ผู้ดูแลระบบปิดสิทธิ์${label || ''}ไว้ใน Permission Center`,
        'error'
      );
      return;
    }
    if (path === '/history') {
      markHistoryRead();
    }
    navigate(path);
  };

  return (
    <div className="space-y-4 pt-1">
      {/* Preview Banner — Factory boiler department preview banner with Welcome (sky blue) and ยินดีต้อนรับ (white, larger) centered vertically */}
      <div className="w-full h-36 rounded-2xl overflow-hidden shadow-xs border border-slate-200 bg-slate-900 relative">
        <img
          src={settings.preview_image_url?.trim() ? settings.preview_image_url.trim() : factoryBoilerBanner}
          alt="Boiler Chemical Management"
          referrerPolicy="no-referrer"
          onError={(e) => {
            const target = e.currentTarget;
            if (target.src !== factoryBoilerBanner) {
              target.src = factoryBoilerBanner;
            }
          }}
          className="w-full h-full object-cover object-center"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-slate-950/75 via-slate-900/45 to-slate-900/20 flex flex-col justify-center px-5">
          <span className="block text-sm font-extrabold tracking-wide text-sky-400 leading-tight drop-shadow-sm">
            Welcome
          </span>
          <span className="block text-2xl font-extrabold text-white leading-tight mt-0.5 drop-shadow-md">
            ยินดีต้อนรับ
          </span>
        </div>
      </div>

      {/* Section Title: "เมนู" */}
      <div className="px-1 pt-0.5">
        <h2 className="text-base font-extrabold text-slate-900">เมนู</h2>
      </div>

      {/* 2x2 Function Grid */}
      <div className="grid grid-cols-2 gap-3.5">
        {/* 1. คำนวณ */}
        <button
          type="button"
          onClick={() => handleOpenMenu('/calculation', 'allow_calculate', 'การคำนวณ')}
          className="group relative min-h-[144px] p-4 rounded-3xl border border-sky-100/90 bg-white hover:border-sky-300 hover:bg-sky-50/40 active:border-sky-400 active:bg-sky-100/60 active:ring-2 active:ring-sky-200/80 active:scale-[0.98] shadow-xs hover:shadow-md transition-all duration-150 flex flex-col items-start justify-between text-left cursor-pointer"
        >
          <div className="w-11 h-11 rounded-2xl bg-sky-50 text-sky-600 border border-sky-100 flex items-center justify-center group-hover:bg-sky-600 group-hover:text-white group-active:bg-sky-600 group-active:text-white transition-colors">
            <Calculator className="w-5 h-5" />
          </div>
          <div className="w-full pt-3">
            <strong className="block text-base font-extrabold text-slate-900 group-active:text-sky-700 transition-colors">คำนวณ</strong>
            <small className="block text-[11px] text-slate-400 mt-0.5">
              คำนวณและบันทึกสารเคมี
            </small>
          </div>
          <ChevronRight className="w-4 h-4 text-sky-300 group-hover:text-sky-500 group-active:text-sky-600 absolute right-4 bottom-4 group-hover:translate-x-0.5 group-active:translate-x-1 transition-all" />
        </button>

        {/* 2. ประวัติ */}
        <button
          type="button"
          onClick={() => handleOpenMenu('/history', 'allow_history_view', 'การดูประวัติ')}
          className="group relative min-h-[144px] p-4 rounded-3xl border border-sky-100/90 bg-white hover:border-sky-300 hover:bg-sky-50/40 active:border-sky-400 active:bg-sky-100/60 active:ring-2 active:ring-sky-200/80 active:scale-[0.98] shadow-xs hover:shadow-md transition-all duration-150 flex flex-col items-start justify-between text-left cursor-pointer"
        >
          <div className="relative w-11 h-11 rounded-2xl bg-sky-50 text-sky-600 border border-sky-100 flex items-center justify-center group-hover:bg-sky-600 group-hover:text-white group-active:bg-sky-600 group-active:text-white transition-colors">
            <History className="w-5 h-5" />
            {hasUnreadHistory && (
              <span className="absolute -top-1 -right-1 w-3 h-3 rounded-full bg-rose-500 ring-2 ring-white" />
            )}
          </div>
          <div className="w-full pt-3">
            <strong className="block text-base font-extrabold text-slate-900 group-active:text-sky-700 transition-colors">ประวัติ</strong>
            <small className="block text-[11px] text-slate-400 mt-0.5">
              ดูรายการที่บันทึกไว้
            </small>
          </div>
          <ChevronRight className="w-4 h-4 text-sky-300 group-hover:text-sky-500 group-active:text-sky-600 absolute right-4 bottom-4 group-hover:translate-x-0.5 group-active:translate-x-1 transition-all" />
        </button>

        {/* 3. สารเคมี */}
        <button
          type="button"
          onClick={() => handleOpenMenu('/chemicals', 'allow_chemical_info', 'ข้อมูลสารเคมี')}
          className="group relative min-h-[144px] p-4 rounded-3xl border border-sky-100/90 bg-white hover:border-sky-300 hover:bg-sky-50/40 active:border-sky-400 active:bg-sky-100/60 active:ring-2 active:ring-sky-200/80 active:scale-[0.98] shadow-xs hover:shadow-md transition-all duration-150 flex flex-col items-start justify-between text-left cursor-pointer"
        >
          <div className="w-11 h-11 rounded-2xl bg-sky-50 text-sky-600 border border-sky-100 flex items-center justify-center group-hover:bg-sky-600 group-hover:text-white group-active:bg-sky-600 group-active:text-white transition-colors">
            <FlaskConical className="w-5 h-5" />
          </div>
          <div className="w-full pt-3">
            <strong className="block text-base font-extrabold text-slate-900 group-active:text-sky-700 transition-colors">สารเคมี</strong>
            <small className="block text-[11px] text-slate-400 mt-0.5">
              ข้อมูลและคุณสมบัติ
            </small>
          </div>
          <ChevronRight className="w-4 h-4 text-sky-300 group-hover:text-sky-500 group-active:text-sky-600 absolute right-4 bottom-4 group-hover:translate-x-0.5 group-active:translate-x-1 transition-all" />
        </button>

        {/* 4. การตั้งค่า */}
        <button
          type="button"
          onClick={() => handleOpenMenu('/settings')}
          className="group relative min-h-[144px] p-4 rounded-3xl border border-sky-100/90 bg-white hover:border-sky-300 hover:bg-sky-50/40 active:border-sky-400 active:bg-sky-100/60 active:ring-2 active:ring-sky-200/80 active:scale-[0.98] shadow-xs hover:shadow-md transition-all duration-150 flex flex-col items-start justify-between text-left cursor-pointer"
        >
          <div className="w-11 h-11 rounded-2xl bg-sky-50 text-sky-600 border border-sky-100 flex items-center justify-center group-hover:bg-sky-600 group-hover:text-white group-active:bg-sky-600 group-active:text-white transition-colors">
            <Settings className="w-5 h-5" />
          </div>
          <div className="w-full pt-3">
            <strong className="block text-base font-extrabold text-slate-900 group-active:text-sky-700 transition-colors">การตั้งค่า</strong>
            <small className="block text-[11px] text-slate-400 mt-0.5">
              จัดการระบบและ Admin
            </small>
          </div>
          <ChevronRight className="w-4 h-4 text-sky-300 group-hover:text-sky-500 group-active:text-sky-600 absolute right-4 bottom-4 group-hover:translate-x-0.5 group-active:translate-x-1 transition-all" />
        </button>
      </div>
    </div>
  );
};
