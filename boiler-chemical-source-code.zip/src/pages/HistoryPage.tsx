import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ChevronLeft, Share2, Trash2, X } from 'lucide-react';
import { useBoiler } from '../context/BoilerContext';
import { CalculationHistoryRecord } from '../types/boiler';

export const HistoryPage: React.FC = () => {
  const navigate = useNavigate();
  const {
    settings,
    history,
    deleteHistoryRecord,
    markHistoryRead,
    adminUnlocked,
    showToast,
  } = useBoiler();

  const [deleteTarget, setDeleteTarget] = useState<CalculationHistoryRecord | null>(null);

  useEffect(() => {
    markHistoryRead();
  }, [markHistoryRead]);

  const buildShareText = (rec: CalculationHistoryRecord) => {
    const detailsText = (rec.details || [])
      .map((d) => `   • ${d.name}\n      - ปริมาณที่ใช้: ${d.report}\n      - คงเหลือ: ${d.curr} L`)
      .join('\n');
    const recNote = (rec.note || rec.details?.find((d) => d.note)?.note || '').trim();
    const noteLine = recNote ? `\n\n📝 หมายเหตุ: ${recNote}` : '';
    const timeStr = new Date(rec.calculated_at).toLocaleString('th-TH');
    return `📋 รายงานสารเคมีของบอยเลอร์ (Boiler Chemical Report)\n\n🏭 Boiler: ${rec.boiler_name}\n📅 วันที่/เวลา: ${timeStr}\n\n📊 สรุปผลการคำนวณ:\n${detailsText}${noteLine}\n\n------------------------`;
  };

  const handleShareItem = async (rec: CalculationHistoryRecord) => {
    if (!settings.permissions.allow_share) {
      showToast('การแชร์ถูกปิดไว้', 'ผู้ดูแลระบบปิดสิทธิ์การแชร์ไว้ใน Permission Center', 'error');
      return;
    }
    const text = buildShareText(rec);
    if (navigator.share) {
      try {
        await navigator.share({ title: 'รายงานสารเคมีบอยเลอร์', text });
      } catch (_e) {
        // cancelled
      }
    } else {
      try {
        await navigator.clipboard.writeText(text);
        showToast('คัดลอกสำเร็จ', 'ข้อความรายงานประวัติได้ถูกคัดลอกลงคลิปบอร์ดแล้ว', 'success');
      } catch (_e) {
        // ignore
      }
    }
  };

  const confirmDelete = async () => {
    if (!deleteTarget) return;
    await deleteHistoryRecord(deleteTarget.id);
    setDeleteTarget(null);
  };

  return (
    <div className="space-y-4">
      {/* Subpage Header */}
      <div className="flex items-center gap-3 pt-1">
        <button
          type="button"
          onClick={() => navigate('/')}
          aria-label="กลับหน้าหลัก"
          className="w-10 h-10 rounded-2xl bg-white border border-sky-100/90 text-sky-700 hover:bg-sky-50/70 hover:border-sky-300 active:bg-sky-100 active:border-sky-400 active:scale-95 flex items-center justify-center text-xl font-bold shadow-2xs transition-all cursor-pointer"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>
        <h2 className="text-lg font-extrabold text-slate-900">ประวัติการใช้งาน</h2>
      </div>

      {/* History List */}
      {history.length === 0 ? (
        <div className="rounded-3xl border border-sky-100/90 bg-white p-10 text-center">
          <p className="text-xs font-bold text-slate-400">ยังไม่มีประวัติการคำนวณ</p>
        </div>
      ) : (
        <div className="space-y-3">
          {history.map((item) => {
            const canDelete = adminUnlocked || settings.permissions.allow_history_delete;
            return (
              <div
                key={item.id}
                className="rounded-3xl border border-sky-100/90 bg-white hover:border-sky-200 active:border-sky-300 active:bg-sky-50/30 p-4 shadow-2xs space-y-2.5 transition-all"
              >
                <div className="flex items-center justify-between gap-2 border-b border-sky-100/80 pb-2">
                  <strong className="text-xs font-extrabold text-sky-700">
                    {item.boiler_name}
                  </strong>
                  <span className="text-[10px] font-semibold text-slate-400">
                    {new Date(item.calculated_at).toLocaleString('th-TH')}
                  </span>
                </div>

                <div className="space-y-1.5">
                  {(item.details || []).map((d, idx) => (
                    <div
                      key={idx}
                      className="flex justify-between items-center text-xs bg-sky-50/35 hover:bg-sky-50/70 active:bg-sky-100/60 px-3 py-2 rounded-xl border border-sky-100/90 transition-colors"
                    >
                      <span className="font-bold text-slate-700">{d.name}</span>
                      <div className="text-right">
                        <span className="text-sky-600 font-black text-xs block">
                          ผล: {d.report}
                        </span>
                        <span className="text-slate-400 text-[9px] font-bold block">
                          เหลือ {d.curr} L
                        </span>
                      </div>
                    </div>
                  ))}
                </div>

                {(item.note || item.details?.find((d) => d.note)?.note) && (
                  <div className="px-3 py-2 rounded-xl bg-amber-50/60 border border-amber-100 text-xs">
                    <span className="text-amber-700 font-bold">หมายเหตุ: </span>
                    <span className="text-slate-700 font-semibold break-words">
                      {item.note || item.details?.find((d) => d.note)?.note}
                    </span>
                  </div>
                )}

                <div className="flex justify-end gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => handleShareItem(item)}
                    className="px-3 py-1.5 rounded-xl bg-white border border-sky-100/90 hover:bg-sky-50 hover:border-sky-300 active:bg-sky-100 active:border-sky-400 active:scale-95 text-sky-700 text-[11px] font-bold flex items-center gap-1 transition-all cursor-pointer"
                  >
                    <Share2 className="w-3.5 h-3.5" />
                    <span>แชร์</span>
                  </button>

                  {canDelete && (
                    <button
                      type="button"
                      onClick={() => setDeleteTarget(item)}
                      className="px-3 py-1.5 rounded-xl bg-rose-50 border border-rose-100 hover:bg-rose-100 active:bg-rose-200 active:scale-95 text-rose-600 text-[11px] font-bold flex items-center gap-1 transition-all cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>ลบ</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deleteTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-sky-950/50 backdrop-blur-xs p-4">
          <div className="bg-white rounded-3xl border border-sky-100 shadow-2xl max-w-xs w-full p-5 text-center relative">
            <button
              type="button"
              onClick={() => setDeleteTarget(null)}
              className="absolute top-3 right-3 w-8 h-8 rounded-full bg-slate-100 text-slate-500 flex items-center justify-center"
            >
              <X className="w-4 h-4" />
            </button>
            <h3 className="text-sm font-extrabold text-slate-900">ยืนยันการลบรายการ</h3>
            <p className="text-xs text-slate-500 mt-1 mb-4">
              ต้องการลบประวัติของ {deleteTarget.boiler_name} ใช่หรือไม่?
            </p>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setDeleteTarget(null)}
                className="py-2.5 rounded-xl bg-slate-100 text-slate-700 font-bold text-xs"
              >
                ยกเลิก
              </button>
              <button
                type="button"
                onClick={confirmDelete}
                className="py-2.5 rounded-xl bg-rose-600 text-white font-bold text-xs"
              >
                ยืนยัน
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
