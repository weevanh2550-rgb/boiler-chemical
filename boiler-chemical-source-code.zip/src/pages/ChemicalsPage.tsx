import React, { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { AnimatePresence, motion } from 'motion/react';
import {
  ChevronLeft,
  ChevronRight,
  BookOpen,
  FlaskConical,
  CheckCircle2,
  Cpu,
  Gauge,
  Droplets,
  Calculator,
} from 'lucide-react';
import { useBoiler } from '../context/BoilerContext';
import { CHEMICAL_KNOWLEDGE_BASE, ChemicalKnowledgeCard } from '../types/boiler';

export const ChemicalsPage: React.FC = () => {
  const navigate = useNavigate();
  const { chemicals } = useBoiler();

  // Merge built-in technical knowledge cards with any custom chemicals added in Admin
  const bookPages = useMemo<ChemicalKnowledgeCard[]>(() => {
    const pages = [...CHEMICAL_KNOWLEDGE_BASE];
    for (const c of chemicals) {
      const exists = pages.some(
        (p) => p.name.toLowerCase() === c.name.toLowerCase()
      );
      if (!exists && c.active) {
        pages.push({
          name: c.name,
          code: c.code || c.name,
          divisor: c.divisor,
          unit: c.unit || 'L',
          badge: `ตัวหาร ÷ ${c.divisor}`,
          summary:
            c.description ||
            `สารเคมีบำบัดน้ำหม้อต้มไอน้ำ (${c.name}) คำนวณปริมาณโดยหารด้วย ${c.divisor}`,
          specs: {
            category: 'Boiler Water Treatment Chemical (สารเคมีบำบัดน้ำหม้อไอน้ำ)',
            appearance: `สารละลายเคมีเหลว (หน่วยวัด ${c.unit || 'L'})`,
            controlTarget: 'ควบคุมคุณภาพน้ำป้อนและน้ำในหม้อต้มตามเกณฑ์มาตรฐาน',
            dosingMethod: `เติมตามปริมาณที่คำนวณได้จากระดับถังเคมีหารด้วย ${c.divisor}`,
            formulaText: `(ค่าล่าสุด - ค่าปัจจุบัน) ÷ ${c.divisor}`,
          },
          topics: [
            {
              title: 'อัตราส่วนและสูตรการคำนวณมาตรฐาน',
              body: `นำผลต่างของระดับน้ำยาล่าสุดและระดับน้ำยาปัจจุบัน มาหารด้วย ${c.divisor} เพื่อหาปริมาณการใช้งานจริงในหน่วย ${c.unit || 'L'}`,
            },
            {
              title: 'การควบคุมคุณภาพน้ำในหม้อต้ม (Boiler Water Control)',
              body: 'ช่วยรักษาคุณภาพน้ำในระบบบอยเลอร์ให้คงที่ ลดความเสี่ยงการเกิดตะกรันและการกัดกร่อนในท่อไอน้ำ',
            },
          ],
        });
      }
    }
    return pages;
  }, [chemicals]);

  const [[pageIndex, direction], setPage] = useState<[number, number]>([0, 0]);
  const [innerTab, setInnerTab] = useState<'PROPERTIES' | 'TECHNICAL'>('PROPERTIES');

  const currentPage = bookPages[pageIndex] || bookPages[0];

  const turnPage = (newDirection: number) => {
    const nextIndex = pageIndex + newDirection;
    if (nextIndex < 0 || nextIndex >= bookPages.length) return;
    setPage([nextIndex, newDirection]);
  };

  const selectDirectPage = (targetIndex: number) => {
    if (targetIndex === pageIndex) return;
    setPage([targetIndex, targetIndex > pageIndex ? 1 : -1]);
  };

  const bookVariants = {
    enter: (dir: number) => ({
      rotateY: dir > 0 ? 78 : -78,
      x: dir > 0 ? 95 : -95,
      opacity: 0,
      scale: 0.95,
    }),
    center: {
      rotateY: 0,
      x: 0,
      opacity: 1,
      scale: 1,
    },
    exit: (dir: number) => ({
      rotateY: dir > 0 ? -78 : 78,
      x: dir > 0 ? -95 : 95,
      opacity: 0,
      scale: 0.95,
    }),
  };

  return (
    <div className="space-y-4">
      {/* Subpage Header */}
      <div className="flex items-center justify-between pt-1">
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={() => navigate('/')}
            aria-label="กลับหน้าหลัก"
            className="w-10 h-10 rounded-2xl bg-white border border-sky-100/90 text-sky-700 hover:bg-sky-50/70 hover:border-sky-300 active:bg-sky-100 active:border-sky-400 active:scale-95 flex items-center justify-center text-xl font-bold shadow-2xs transition-all cursor-pointer"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          <div>
            <h2 className="text-lg font-extrabold text-slate-900">คุณสมบัติสารเคมี</h2>
            <p className="text-[11px] text-slate-400">
              แตะเลือกสารเคมี หรือสไลด์ซ้าย-ขวาเพื่อเปิดหน้าสมุด
            </p>
          </div>
        </div>

        <span className="px-2.5 py-1 rounded-xl bg-sky-50 border border-sky-100/90 text-sky-700 text-xs font-extrabold">
          หน้า {pageIndex + 1} / {bookPages.length}
        </span>
      </div>

      {/* Chemical Bookmark Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar">
        {bookPages.map((chem, idx) => {
          const isSelected = idx === pageIndex;
          return (
            <button
              key={chem.code + idx}
              type="button"
              onClick={() => selectDirectPage(idx)}
              className={`px-3.5 py-2 rounded-2xl text-xs font-extrabold shrink-0 transition-all flex items-center gap-1.5 cursor-pointer ${
                isSelected
                  ? 'bg-sky-600 text-white border border-sky-600 shadow-sm shadow-sky-500/25 -translate-y-0.5'
                  : 'bg-white border border-sky-100/90 text-slate-600 hover:bg-sky-50/60 hover:border-sky-300 active:bg-sky-100/80 active:border-sky-400 active:scale-95'
              }`}
            >
              <FlaskConical className="w-3.5 h-3.5" />
              <span>{chem.name}</span>
              <span
                className={`text-[10px] px-1.5 py-0.5 rounded-md ${
                  isSelected ? 'bg-white/20 text-white' : 'bg-sky-50 text-sky-700'
                }`}
              >
                ÷{chem.divisor}
              </span>
            </button>
          );
        })}
      </div>

      {/* 3D Interactive Notebook / Flipbook Stage */}
      <div className="relative" style={{ perspective: '1500px' }}>
        {/* Layered Book Pages Underneath */}
        <div className="absolute inset-x-2.5 -bottom-2.5 h-full rounded-[28px] bg-sky-100/60 border border-sky-200/60 -z-10" />
        <div className="absolute inset-x-1 -bottom-1.5 h-full rounded-[28px] bg-sky-50/90 border border-sky-100 -z-10" />

        <AnimatePresence mode="wait" custom={direction}>
          <motion.div
            key={pageIndex}
            custom={direction}
            variants={bookVariants}
            initial="enter"
            animate="center"
            exit="exit"
            transition={{
              duration: 0.4,
              ease: [0.22, 1, 0.36, 1],
            }}
            drag="x"
            dragConstraints={{ left: 0, right: 0 }}
            dragElastic={0.22}
            onDragEnd={(_e, info) => {
              if (info.offset.x < -45 && pageIndex < bookPages.length - 1) {
                turnPage(1);
              } else if (info.offset.x > 45 && pageIndex > 0) {
                turnPage(-1);
              }
            }}
            style={{ transformOrigin: direction >= 0 ? 'left center' : 'right center' }}
            className="relative rounded-[28px] bg-white border border-sky-100/90 hover:border-sky-200 active:border-sky-300 shadow-xl overflow-hidden flex min-h-[470px] cursor-grab active:cursor-grabbing transition-colors"
          >
            {/* Left Notebook Spiral Rings & Spine Shadow */}
            <div className="w-9 sm:w-11 bg-gradient-to-r from-sky-100 via-sky-50 to-white border-r border-sky-200/80 flex flex-col items-center justify-evenly py-6 shrink-0 select-none">
              {[0, 1, 2, 3, 4, 5, 6, 7].map((ring) => (
                <div key={ring} className="flex items-center">
                  <div className="w-3.5 h-3.5 rounded-full bg-slate-200 border-2 border-sky-300 shadow-inner" />
                  <div className="w-2.5 h-1 bg-sky-400 -ml-1 rounded-r-full" />
                </div>
              ))}
            </div>

            {/* Right Notebook Page Content */}
            <div className="flex-1 p-4 sm:p-5 flex flex-col justify-between bg-[linear-gradient(to_bottom,transparent_31px,#f0f9ff_32px)] bg-[size:100%_32px]">
              <div>
                {/* Notebook Page Top Header */}
                <div className="flex items-start justify-between gap-2 border-b-2 border-sky-500/20 pb-3 mb-3">
                  <div>
                    <div className="inline-flex items-center gap-1.5 text-[10px] font-black uppercase tracking-widest text-sky-600">
                      <BookOpen className="w-3.5 h-3.5" />
                      <span>NOTEBOOK PAGE 0{pageIndex + 1}</span>
                    </div>
                    <h3 className="text-xl font-black text-slate-900 mt-0.5">
                      {currentPage.name}
                    </h3>
                  </div>

                  <span className="px-3 py-1 rounded-xl bg-sky-600 text-white text-xs font-black shadow-2xs shrink-0">
                    {currentPage.badge}
                  </span>
                </div>

                {/* Inner Sub-View Toggle: คุณสมบัติหลัก vs ข้อมูลทางเทคนิค */}
                <div className="grid grid-cols-2 gap-1.5 p-1 rounded-2xl bg-sky-50 border border-sky-100 mb-3.5">
                  <button
                    type="button"
                    onClick={() => setInnerTab('PROPERTIES')}
                    className={`py-1.5 rounded-xl text-[11px] font-extrabold transition-all cursor-pointer ${
                      innerTab === 'PROPERTIES'
                        ? 'bg-white text-sky-700 shadow-2xs'
                        : 'text-slate-500 hover:text-sky-700'
                    }`}
                  >
                    คุณสมบัติและการทำงาน
                  </button>
                  <button
                    type="button"
                    onClick={() => setInnerTab('TECHNICAL')}
                    className={`py-1.5 rounded-xl text-[11px] font-extrabold transition-all cursor-pointer ${
                      innerTab === 'TECHNICAL'
                        ? 'bg-white text-sky-700 shadow-2xs'
                        : 'text-slate-500 hover:text-sky-700'
                    }`}
                  >
                    ข้อมูลทางเทคนิค & สูตร
                  </button>
                </div>

                {innerTab === 'PROPERTIES' ? (
                  <div className="space-y-2.5">
                    <p className="text-xs font-semibold text-sky-900 bg-sky-50/90 border border-sky-200/80 rounded-2xl p-3">
                      {currentPage.summary}
                    </p>

                    {currentPage.topics.map((topic, idx) => (
                      <div
                        key={idx}
                        className="p-3 rounded-2xl bg-white/95 border border-sky-100 shadow-2xs space-y-1"
                      >
                        <div className="flex items-center gap-1.5">
                          <CheckCircle2 className="w-4 h-4 text-sky-600 shrink-0" />
                          <strong className="text-xs font-extrabold text-slate-900">
                            {topic.title}
                          </strong>
                        </div>
                        <p className="text-[11px] text-slate-600 leading-relaxed pl-5">
                          {topic.body}
                        </p>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="space-y-2.5">
                    <div className="p-3.5 rounded-2xl bg-gradient-to-r from-sky-600 to-blue-600 text-white shadow-xs">
                      <div className="flex items-center gap-1.5 text-[10px] font-bold text-sky-100 uppercase tracking-wider">
                        <Calculator className="w-3.5 h-3.5" />
                        <span>สูตรคำนวณมาตรฐานประจำกะ</span>
                      </div>
                      <p className="text-sm font-black mt-1">
                        {currentPage.specs.formulaText}
                      </p>
                      <p className="text-[11px] text-sky-100 mt-0.5">
                        หน่วยวัดผลลัพธ์: ปริมาณน้ำยาที่ใช้จริง ({currentPage.unit})
                      </p>
                    </div>

                    <div className="p-3 rounded-2xl bg-white/95 border border-sky-100 space-y-1">
                      <div className="flex items-center gap-1.5 text-xs font-extrabold text-slate-800">
                        <Cpu className="w-3.5 h-3.5 text-sky-600" />
                        <span>ประเภทสารเคมี (Classification)</span>
                      </div>
                      <p className="text-[11px] text-slate-600 pl-5">
                        {currentPage.specs.category}
                      </p>
                    </div>

                    <div className="p-3 rounded-2xl bg-white/95 border border-sky-100 space-y-1">
                      <div className="flex items-center gap-1.5 text-xs font-extrabold text-slate-800">
                        <Gauge className="w-3.5 h-3.5 text-sky-600" />
                        <span>เป้าหมายการควบคุม (Control Target)</span>
                      </div>
                      <p className="text-[11px] text-slate-600 pl-5">
                        {currentPage.specs.controlTarget}
                      </p>
                    </div>

                    <div className="p-3 rounded-2xl bg-white/95 border border-sky-100 space-y-1">
                      <div className="flex items-center gap-1.5 text-xs font-extrabold text-slate-800">
                        <Droplets className="w-3.5 h-3.5 text-sky-600" />
                        <span>ลักษณะทางกายภาพและการจ่ายยา</span>
                      </div>
                      <p className="text-[11px] text-slate-600 pl-5">
                        {currentPage.specs.appearance} • {currentPage.specs.dosingMethod}
                      </p>
                    </div>
                  </div>
                )}
              </div>

              {/* Bottom Notebook Page Footer */}
              <div className="mt-4 pt-3 border-t border-sky-100 flex items-center justify-between text-[11px] text-slate-400 font-semibold">
                <span>ปัดซ้าย-ขวาเพื่อเปลี่ยนหน้า</span>
                <span className="text-sky-600 font-bold">
                  หน้า {pageIndex + 1} / {bookPages.length}
                </span>
              </div>
            </div>
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Bottom Book Page Turn Controls */}
      <div className="flex items-center justify-between gap-3 pt-1">
        <button
          type="button"
          onClick={() => turnPage(-1)}
          disabled={pageIndex === 0}
          className="flex-1 py-3 px-4 rounded-2xl bg-white border border-sky-200 text-sky-700 hover:bg-sky-50 disabled:opacity-40 font-extrabold text-xs flex items-center justify-center gap-1.5 shadow-2xs transition-all cursor-pointer disabled:cursor-not-allowed"
        >
          <ChevronLeft className="w-4 h-4" />
          <span>หน้าก่อนหน้า</span>
        </button>

        <div className="flex items-center gap-1.5 px-2">
          {bookPages.map((_, idx) => (
            <button
              key={idx}
              type="button"
              onClick={() => selectDirectPage(idx)}
              aria-label={`ไปหน้าที่ ${idx + 1}`}
              className={`h-2 rounded-full transition-all cursor-pointer ${
                idx === pageIndex ? 'w-6 bg-sky-600' : 'w-2 bg-sky-200'
              }`}
            />
          ))}
        </div>

        <button
          type="button"
          onClick={() => turnPage(1)}
          disabled={pageIndex === bookPages.length - 1}
          className="flex-1 py-3 px-4 rounded-2xl bg-sky-600 hover:bg-sky-700 disabled:opacity-40 text-white font-extrabold text-xs flex items-center justify-center gap-1.5 shadow-sm transition-all cursor-pointer disabled:cursor-not-allowed"
        >
          <span>พลิกหน้าถัดไป</span>
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
