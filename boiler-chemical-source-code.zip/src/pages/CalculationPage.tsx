import React, { useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ChevronLeft, Check, Share2, X } from 'lucide-react';
import { useBoiler } from '../context/BoilerContext';
import { CalculationDetailItem, CalculationHistoryRecord } from '../types/boiler';

interface ChemInputPair {
  prev: string;
  curr: string;
}

export const CalculationPage: React.FC = () => {
  const navigate = useNavigate();
  const {
    settings,
    boilers,
    chemicals,
    getLatestLevelForBoiler,
    submitCalculation,
    showToast,
  } = useBoiler();

  const activeBoilers = useMemo(() => boilers.filter((b) => b.active), [boilers]);
  const activeChemicals = useMemo(() => chemicals.filter((c) => c.active), [chemicals]);

  const [selectedBoilerName, setSelectedBoilerName] = useState<string>('');
  const [inputs, setInputs] = useState<Record<string, ChemInputPair>>({});
  const [note, setNote] = useState<string>('');
  const [touchedChems, setTouchedChems] = useState<Record<string, boolean>>({});
  const [resultModalRecord, setResultModalRecord] = useState<CalculationHistoryRecord | null>(null);
  const lastSelectedBoilerRef = useRef<string>('');

  // Auto-load "ล่าสุด (L)" only when selecting/changing Boiler, without resetting inputs on background sync
  useEffect(() => {
    const boilerChanged = lastSelectedBoilerRef.current !== selectedBoilerName;
    lastSelectedBoilerRef.current = selectedBoilerName;

    if (!selectedBoilerName) {
      if (boilerChanged) {
        setTouchedChems({});
        setInputs({});
        setNote('');
      }
      return;
    }

    if (boilerChanged) {
      setTouchedChems({});
      const nextInputs: Record<string, ChemInputPair> = {};
      for (const chem of activeChemicals) {
        const latestCurr = getLatestLevelForBoiler(selectedBoilerName, chem.name);
        nextInputs[chem.id] = {
          prev: latestCurr !== null ? String(latestCurr) : '',
          curr: '',
        };
      }
      setInputs(nextInputs);
      return;
    }

    // Preserve all current user inputs during background polling/sync; only populate uninitialized fields
    setInputs((prevInputs) => {
      let changed = false;
      const merged: Record<string, ChemInputPair> = { ...prevInputs };
      for (const chem of activeChemicals) {
        const existing = merged[chem.id];
        if (!existing) {
          const latestCurr = getLatestLevelForBoiler(selectedBoilerName, chem.name);
          merged[chem.id] = {
            prev: latestCurr !== null ? String(latestCurr) : '',
            curr: '',
          };
          changed = true;
        } else if (
          !touchedChems[chem.id] &&
          existing.prev === '' &&
          existing.curr === ''
        ) {
          const latestCurr = getLatestLevelForBoiler(selectedBoilerName, chem.name);
          if (latestCurr !== null) {
            merged[chem.id] = {
              prev: String(latestCurr),
              curr: '',
            };
            changed = true;
          }
        }
      }
      return changed ? merged : prevInputs;
    });
  }, [selectedBoilerName, activeChemicals, getLatestLevelForBoiler, touchedChems]);

  const handleInputChange = (chemId: string, field: keyof ChemInputPair, value: string) => {
    setTouchedChems((prev) => ({ ...prev, [chemId]: true }));
    setInputs((prev) => ({
      ...prev,
      [chemId]: {
        ...(prev[chemId] || { prev: '', curr: '' }),
        [field]: value,
      },
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!settings.permissions.allow_calculate) {
      showToast('ฟังก์ชันถูกปิดไว้', 'ผู้ดูแลระบบปิดสิทธิ์การคำนวณไว้ใน Permission Center', 'error');
      return;
    }
    if (!settings.permissions.allow_save) {
      showToast('การบันทึกถูกปิดไว้', 'ผู้ดูแลระบบปิดสิทธิ์การบันทึกไว้ใน Permission Center', 'error');
      return;
    }
    if (!selectedBoilerName) {
      showToast('ยังไม่ได้เลือก Boiler', 'กรุณาเลือก Boiler ก่อนทำการคำนวณและบันทึกข้อมูล', 'error');
      return;
    }

    const details: CalculationDetailItem[] = [];
    for (const chem of activeChemicals) {
      const pair = inputs[chem.id] || { prev: '', curr: '' };
      const prevRaw = pair.prev.trim();
      const currRaw = pair.curr.trim();

      if (prevRaw === '' && currRaw === '') continue;

      if (prevRaw === '' && currRaw !== '') {
        showToast(
          'กรอกข้อมูลไม่ครบ',
          `กรุณากรอกค่า ${chem.name} ให้ครบทั้งช่อง ล่าสุด และ ปัจจุบัน`,
          'error'
        );
        return;
      }

      if (prevRaw !== '' && currRaw === '') {
        if (touchedChems[chem.id]) {
          showToast(
            'กรอกข้อมูลไม่ครบ',
            `กรุณากรอกค่า ${chem.name} ให้ครบทั้งช่อง ล่าสุด และ ปัจจุบัน`,
            'error'
          );
          return;
        }
        continue;
      }

      const prevNum = Number(prevRaw);
      const currNum = Number(currRaw);
      if (!Number.isFinite(prevNum) || !Number.isFinite(currNum) || prevNum < 0 || currNum < 0) {
        showToast(
          `ข้อมูล ${chem.name} ไม่ถูกต้อง`,
          'กรุณากรอกตัวเลขให้ครบทั้งช่อง ล่าสุด และ ปัจจุบัน',
          'error'
        );
        return;
      }

      if (prevNum > 0 && currNum > prevNum) {
        showToast(
          `ข้อมูล ${chem.name} ไม่ถูกต้อง`,
          'ค่าปัจจุบันต้องไม่มากกว่าค่าล่าสุด',
          'error'
        );
        return;
      }

      const dosage =
        prevNum === 0
          ? Math.max(0, currNum / chem.divisor)
          : Math.max(0, (prevNum - currNum) / chem.divisor);

      const cleanNote = note.trim();
      details.push({
        name: chem.name,
        prev: prevNum,
        curr: currNum,
        divisor: chem.divisor,
        report: dosage.toFixed(2),
        ...(cleanNote ? { note: cleanNote } : {}),
      });
    }

    if (details.length === 0) {
      showToast(
        'กรอกข้อมูลไม่ครบ',
        'กรุณากรอกค่าให้ครบทั้งช่อง ล่าสุด และ ปัจจุบัน ก่อนทำการคำนวณ',
        'error'
      );
      return;
    }

    const boilerRow = activeBoilers.find(
      (b) => b.name.replace(/\s+/g, '').toLowerCase() === selectedBoilerName.replace(/\s+/g, '').toLowerCase()
    );

    const cleanNote = note.trim();
    const response = await submitCalculation({
      boiler_id: boilerRow?.id || null,
      boiler_name: selectedBoilerName,
      recorder_name: 'แผนกบอยเลอร์',
      ...(cleanNote ? { note: cleanNote } : {}),
      details,
    });

    if (response.ok && response.record) {
      setResultModalRecord(response.record);
      setTouchedChems({});
      setNote('');
      const updatedInputs: Record<string, ChemInputPair> = {};
      for (const chem of activeChemicals) {
        const savedDetail = details.find((d) => d.name === chem.name);
        const fallbackLatest = getLatestLevelForBoiler(selectedBoilerName, chem.name);
        updatedInputs[chem.id] = {
          prev:
            savedDetail !== undefined
              ? String(savedDetail.curr)
              : fallbackLatest !== null
              ? String(fallbackLatest)
              : '',
          curr: '',
        };
      }
      setInputs(updatedInputs);
    }
  };

  const buildShareText = (rec: CalculationHistoryRecord) => {
    const detailsText = (rec.details || [])
      .map((d) => `   • ${d.name}\n      - ปริมาณที่ใช้: ${d.report}\n      - คงเหลือ: ${d.curr} L`)
      .join('\n');
    const recNote = (rec.note || rec.details?.find((d) => d.note)?.note || '').trim();
    const noteLine = recNote ? `\n\n📝 หมายเหตุ: ${recNote}` : '';
    const timeStr = new Date(rec.calculated_at).toLocaleString('th-TH');
    return `📋 รายงานสารเคมีของบอยเลอร์ (Boiler Chemical Report)\n\n🏭 Boiler: ${rec.boiler_name}\n📅 วันที่/เวลา: ${timeStr}\n\n📊 สรุปผลการคำนวณ:\n${detailsText}${noteLine}\n\n------------------------`;
  };

  const handleShare = async (rec: CalculationHistoryRecord) => {
    if (!settings.permissions.allow_share) {
      showToast('การแชร์ถูกปิดไว้', 'ผู้ดูแลระบบปิดสิทธิ์การแชร์ไว้ใน Permission Center', 'error');
      return;
    }
    const text = buildShareText(rec);
    if (navigator.share) {
      try {
        await navigator.share({ title: 'รายงานสารเคมีบอยเลอร์', text });
      } catch (_e) {
        // cancelled
      }
    } else {
      try {
        await navigator.clipboard.writeText(text);
        showToast('คัดลอกสำเร็จ', 'ข้อความรายงานได้ถูกคัดลอกลงคลิปบอร์ดแล้ว', 'success');
      } catch (_e) {
        // ignore
      }
    }
  };

  return (
    <div className="space-y-4">
      {/* Subpage Header */}
      <div className="flex items-center gap-3 pt-1">
        <button
          type="button"
          onClick={() => navigate('/')}
          aria-label="กลับหน้าหลัก"
          className="w-10 h-10 rounded-2xl bg-white border border-sky-100/90 text-sky-700 hover:bg-sky-50/70 hover:border-sky-300 active:bg-sky-100 active:border-sky-400 active:scale-95 flex items-center justify-center text-xl font-bold shadow-2xs transition-all cursor-pointer"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>
        <h2 className="text-lg font-extrabold text-slate-900">คำนวณสารเคมี</h2>
      </div>

      {/* กรอบที่ 1: เลือก Boiler (กรอบสีฟ้าจางขาวสะอาดตา เมื่อกด/เลือกจะขึ้นเอฟเฟกต์สีฟ้าชัดขึ้น) */}
      <div className="rounded-2xl bg-white border border-sky-100/90 hover:border-sky-200 focus-within:border-sky-400 focus-within:bg-sky-50/20 focus-within:ring-2 focus-within:ring-sky-100 px-3.5 py-3 shadow-2xs transition-all">
        <label
          htmlFor="boilerSelect"
          className="block text-xs font-extrabold text-slate-800 mb-1.5"
        >
          📍 เลือก Boiler
        </label>
        <select
          id="boilerSelect"
          value={selectedBoilerName}
          onChange={(e) => setSelectedBoilerName(e.target.value)}
          className="w-full rounded-xl border border-sky-100/90 bg-sky-50/30 px-3 py-2 text-xs font-bold text-slate-800 hover:border-sky-200 focus:bg-white focus:ring-2 focus:ring-sky-200 focus:border-sky-400 active:bg-sky-50/70 outline-none transition-all cursor-pointer"
        >
          <option value="">-- กรุณาเลือก --</option>
          {activeBoilers.map((b) => (
            <option key={b.id} value={b.name}>
              {b.name}
            </option>
          ))}
        </select>
      </div>

      {/* กรอบที่ 2: รายการสารเคมี (กรอบสีฟ้าจางอมขาว เมื่อจิ้มช่องกรอกจะมีสีฟ้าเพิ่มขึ้น) */}
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="rounded-3xl bg-white border border-sky-100/90 p-4 shadow-2xs transition-all">
          <label className="block text-xs font-extrabold text-slate-800 mb-2.5">
            🧪 รายการสารเคมี
          </label>
          <div className="space-y-2.5">
            {activeChemicals.map((chem) => {
              const pair = inputs[chem.id] || { prev: '', curr: '' };
              const isDisabled = !selectedBoilerName;

              return (
                <div
                  key={chem.id}
                  className="grid grid-cols-12 gap-2.5 items-center bg-sky-50/25 hover:bg-sky-50/50 focus-within:bg-sky-50/70 focus-within:border-sky-300 focus-within:ring-2 focus-within:ring-sky-100 p-3.5 rounded-2xl border border-sky-100/90 transition-all"
                >
                  <div className="col-span-12 sm:col-span-4 flex sm:flex-col justify-between items-center sm:items-start">
                    <span className="font-extrabold text-slate-800 text-xs">{chem.name}</span>
                    <span className="text-[10px] text-sky-700 font-bold bg-white px-2 py-0.5 rounded-lg border border-sky-100/90 mt-0.5">
                      ÷ {chem.divisor}
                    </span>
                  </div>

                  <div className="col-span-6 sm:col-span-4">
                    <label className="block text-[10px] text-slate-500 font-bold mb-1 ml-1">
                      ล่าสุด ({chem.unit || 'L'})
                    </label>
                    <input
                      type="number"
                      step="any"
                      disabled={isDisabled}
                      value={pair.prev}
                      onChange={(e) => handleInputChange(chem.id, 'prev', e.target.value)}
                      placeholder={isDisabled ? 'เลือก Boiler ก่อน' : 'กรอกค่า'}
                      className="w-full rounded-xl border border-sky-100/90 bg-white px-3 py-2 text-xs text-slate-800 font-bold hover:border-sky-200 focus:bg-sky-50/30 focus:ring-2 focus:ring-sky-200 focus:border-sky-400 outline-none transition-all placeholder:font-normal disabled:bg-slate-50 disabled:border-slate-200/70 disabled:text-slate-400"
                    />
                  </div>

                  <div className="col-span-6 sm:col-span-4">
                    <label className="block text-[10px] text-slate-600 font-bold mb-1 ml-1">
                      ปัจจุบัน ({chem.unit || 'L'})
                    </label>
                    <input
                      type="number"
                      step="any"
                      disabled={isDisabled}
                      value={pair.curr}
                      onChange={(e) => handleInputChange(chem.id, 'curr', e.target.value)}
                      placeholder={isDisabled ? 'เลือก Boiler ก่อน' : 'กรอกค่า'}
                      className="w-full rounded-xl border border-sky-100/90 bg-white px-3 py-2 text-xs text-slate-900 font-bold hover:border-sky-200 focus:bg-sky-50/30 focus:ring-2 focus:ring-sky-200 focus:border-sky-400 outline-none transition-all placeholder:font-normal disabled:bg-slate-50 disabled:border-slate-200/70 disabled:text-slate-400"
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* กรอบที่ 3: ช่องหมายเหตุ (ไม่บังคับกรอก) */}
        <div className="rounded-3xl bg-white border border-sky-100/90 hover:border-sky-200 focus-within:border-sky-400 focus-within:bg-sky-50/20 focus-within:ring-2 focus-within:ring-sky-100 p-4 shadow-2xs transition-all">
          <label
            htmlFor="calculationNote"
            className="block text-xs font-extrabold text-slate-800 mb-2"
          >
            📝 หมายเหตุ
          </label>
          <input
            id="calculationNote"
            type="text"
            value={note}
            onChange={(e) => setNote(e.target.value)}
            placeholder="ระบุหมายเหตุหรือปัญหาที่พบ (ถ้ามี)..."
            className="w-full rounded-xl border border-sky-100/90 bg-sky-50/25 px-3.5 py-2.5 text-xs font-bold text-slate-800 hover:border-sky-200 focus:bg-white focus:ring-2 focus:ring-sky-200 focus:border-sky-400 outline-none transition-all placeholder:font-normal placeholder:text-slate-400"
          />
        </div>

        {/* Submit Button */}
        <button
          type="submit"
          className="w-full py-3.5 rounded-2xl bg-sky-600 hover:bg-sky-700 active:bg-sky-800 active:scale-[0.99] text-white font-extrabold text-sm shadow-md shadow-sky-600/20 flex items-center justify-center gap-2 transition-all cursor-pointer"
        >
          <Check className="w-4 h-4 stroke-[3]" />
          <span>ดำเนินการ</span>
        </button>
      </form>

      {/* Result Modal */}
      {resultModalRecord && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/45 backdrop-blur-xs p-4">
          <div className="bg-white rounded-3xl border border-slate-200 shadow-2xl max-w-sm w-full p-5 relative">
            <button
              type="button"
              onClick={() => setResultModalRecord(null)}
              className="absolute top-4 right-4 w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 flex items-center justify-center text-slate-500"
            >
              <X className="w-4 h-4" />
            </button>

            <h3 className="text-base font-extrabold text-slate-900 mb-3">ผลการคำนวณสารเคมี</h3>

            <div className="rounded-2xl bg-slate-50 border border-slate-200/80 p-3.5 text-xs">
              <div className="border-b border-slate-200 pb-2 mb-2 space-y-1">
                <div className="flex justify-between">
                  <span className="text-slate-500 font-medium">Boiler:</span>
                  <strong className="text-slate-900">{resultModalRecord.boiler_name}</strong>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500 font-medium">เวลา:</span>
                  <span className="text-slate-700">
                    {new Date(resultModalRecord.calculated_at).toLocaleString('th-TH')}
                  </span>
                </div>
              </div>

              <div className="space-y-1.5 mt-2">
                {resultModalRecord.details.map((d, idx) => (
                  <div
                    key={idx}
                    className="flex justify-between items-center bg-white p-2.5 rounded-xl border border-slate-200/80 shadow-2xs"
                  >
                    <span className="font-bold text-slate-800">{d.name}</span>
                    <div className="text-right">
                      <span className="text-sky-600 font-black text-sm block">
                        ผล: {d.report}
                      </span>
                      <span className="text-slate-400 text-[9px] uppercase tracking-wider block -mt-0.5 font-bold">
                        เหลือ {d.curr} L
                      </span>
                    </div>
                  </div>
                ))}
              </div>

              {(resultModalRecord.note || resultModalRecord.details?.find((d) => d.note)?.note) && (
                <div className="mt-2.5 pt-2 border-t border-slate-200/80 text-xs">
                  <span className="text-slate-500 font-bold">หมายเหตุ: </span>
                  <span className="text-slate-800 font-semibold break-words">
                    {resultModalRecord.note || resultModalRecord.details?.find((d) => d.note)?.note}
                  </span>
                </div>
              )}
            </div>

            <div className="grid grid-cols-2 gap-2 mt-4">
              <button
                type="button"
                onClick={() => handleShare(resultModalRecord)}
                className="py-2.5 rounded-xl bg-sky-600 hover:bg-sky-700 text-white font-bold text-xs flex items-center justify-center gap-1.5"
              >
                <Share2 className="w-3.5 h-3.5" />
                <span>แชร์รายงาน</span>
              </button>
              <button
                type="button"
                onClick={() => setResultModalRecord(null)}
                className="py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs"
              >
                ตกลง
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
